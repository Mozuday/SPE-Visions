import { ArrowUpRight, BookOpen, Award, Clock3 } from "lucide-react";
import { Link } from "react-router-dom";

import SectionTitle from "../ui/SectionTitle";
import Reveal from "../effects/Reveal";
import FloatingCard from "../effects/FloatingCard";
import SectionGlow from "../effects/SectionGlow";

const courses = [
  {
    title: "Full Stack Development",
    duration: "12 Weeks",
    level: "Advanced",
    description:
      "Build complete web applications while learning frontend, backend, databases, APIs and deployment.",
  },
  {
    title: "Frontend Development",
    duration: "6 Weeks",
    level: "Beginner",
    description:
      "Learn modern frontend development and build responsive interfaces using JavaScript, React and Tailwind CSS.",
  },
  {
    title: "Backend Development",
    duration: "8 Weeks",
    level: "Intermediate",
    description:
      "Learn APIs, authentication, databases and server-side development through practical projects.",
  },
];

const CoursesPreview = () => {
  return (
    <section className="relative overflow-hidden border-b border-slate-200 bg-white py-28 dark:border-slate-800 dark:bg-slate-950">
      <SectionGlow
        size={360}
        color="blue"
        className="-left-32 top-10 opacity-20"
      />

      <SectionGlow
        size={300}
        color="cyan"
        className="-right-32 bottom-0 opacity-15"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        <Reveal>
          <SectionTitle
            eyebrow="SPE Academy"
            title="Learn Skills That Companies Actually Need"
            description="Industry-focused courses designed around practical development, real projects and career-ready skills."
          />
        </Reveal>

        <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {courses.map((course, index) => (
            <Reveal key={course.title} delay={index * 100}>
              <FloatingCard
                glow
                floating={false}
                rotate
                intensity={5}
                className="group h-full p-7"
              >
                <div className="flex h-full flex-col">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-blue-100 bg-blue-50 text-blue-600 dark:border-blue-900/50 dark:bg-blue-950/40 dark:text-blue-400">
                    <BookOpen size={22} />
                  </div>

                  <h3 className="mt-7 text-xl font-semibold text-slate-900 dark:text-white">
                    {course.title}
                  </h3>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                      <Clock3 size={14} />
                      {course.duration}
                    </span>

                    <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">
                      {course.level}
                    </span>
                  </div>

                  <p className="mt-5 flex-1 text-sm leading-7 text-slate-600 dark:text-slate-400">
                    {course.description}
                  </p>

                  <div className="mt-7 flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                    <Award size={16} />
                    Certificate included
                  </div>

                  <Link
                    to="/courses"
                    className="mt-7 inline-flex w-fit items-center gap-2 text-sm font-semibold text-slate-900 transition-all duration-200 hover:gap-3 hover:text-blue-600 dark:text-white dark:hover:text-blue-400"
                  >
                    View course

                    <ArrowUpRight
                      size={16}
                      className="transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                    />
                  </Link>
                </div>
              </FloatingCard>
            </Reveal>
          ))}
        </div>

        <Reveal delay={400}>
          <div className="mt-16 rounded-3xl border border-blue-200/70 bg-slate-50 p-8 dark:border-blue-900/40 dark:bg-slate-900/60 md:p-12">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400">
                <Award size={24} />
              </div>

              <h3 className="mt-6 text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
                Learn. Build. Get Certified.
              </h3>

              <p className="mt-4 text-sm leading-7 text-slate-600 dark:text-slate-400 md:text-base">
                Focus on practical development instead of theory alone.
                Build projects, strengthen your portfolio and prepare for
                internships, freelancing and full-time opportunities.
              </p>

              <Link
                to="/courses"
                className="mt-7 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white transition-all duration-200 hover:bg-blue-600 hover:shadow-lg hover:shadow-blue-500/20 dark:bg-white dark:text-slate-950 dark:hover:bg-blue-500 dark:hover:text-white"
              >
                Explore all courses
                <ArrowUpRight size={17} />
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default CoursesPreview;