import {
  ArrowUpRight,
  Sparkles,
  ExternalLink,
  Code2,
  Layers3,
} from "lucide-react";
import { Link } from "react-router-dom";

import AnimatedBackground from "../effects/AnimatedBackground";
import Reveal from "../effects/Reveal";
import FloatingCard from "../effects/FloatingCard";
import SectionGlow from "../effects/SectionGlow";

const PortfolioPreview = () => {
  return (
    <section className="relative overflow-hidden border-b border-slate-200 bg-white py-28 dark:border-slate-800 dark:bg-slate-950">

      {/* Background */}
      <AnimatedBackground />

      <SectionGlow
        size={380}
        color="purple"
        className="-left-32 top-10 opacity-20"
      />

      <SectionGlow
        size={300}
        color="blue"
        className="-right-24 bottom-0 opacity-10"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6">

        {/* Heading */}
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">

            <span className="inline-flex items-center gap-2 rounded-full border border-blue-200 bg-blue-50/80 px-5 py-2 text-sm font-semibold text-blue-700 dark:border-cyan-500/20 dark:bg-cyan-500/5 dark:text-cyan-300">
              <Sparkles size={14} />
              Selected Projects
            </span>

            <h2 className="mt-6 text-4xl font-bold tracking-tight text-slate-900 md:text-5xl dark:text-white">
              Crafted with Design.

              <span className="block bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
                Powered by Engineering.
              </span>
            </h2>

            <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-slate-600 dark:text-slate-400">
              We build digital products with a strong focus on clean design,
              reliable architecture, performance and a smooth user experience.
            </p>

          </div>
        </Reveal>

        {/* Project Preview */}
        <Reveal delay={200}>
          <div className="mt-16 grid gap-6 md:grid-cols-3">

            <FloatingCard
              floating={false}
              className="group p-7"
            >
              <div className="flex items-center justify-between">

                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-cyan-400">
                  <Code2 size={23} />
                </div>

                <ExternalLink
                  size={18}
                  className="text-slate-400 transition group-hover:text-blue-600 dark:group-hover:text-cyan-400"
                />

              </div>

              <p className="mt-7 text-xs font-semibold uppercase tracking-wider text-blue-600 dark:text-cyan-400">
                Web Development
              </p>

              <h3 className="mt-2 text-xl font-bold text-slate-900 dark:text-white">
                Modern Web Applications
              </h3>

              <p className="mt-4 leading-7 text-slate-600 dark:text-slate-400">
                Responsive and scalable web applications designed around
                real business requirements.
              </p>

              <div className="mt-6 flex flex-wrap gap-2">

                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                  React
                </span>

                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                  TypeScript
                </span>

              </div>

            </FloatingCard>

            <FloatingCard
              floating={false}
              className="group p-7"
            >
              <div className="flex items-center justify-between">

                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-50 text-cyan-600 dark:bg-cyan-500/10 dark:text-cyan-400">
                  <Layers3 size={23} />
                </div>

                <ExternalLink
                  size={18}
                  className="text-slate-400 transition group-hover:text-cyan-500"
                />

              </div>

              <p className="mt-7 text-xs font-semibold uppercase tracking-wider text-cyan-600 dark:text-cyan-400">
                Software Solutions
              </p>

              <h3 className="mt-2 text-xl font-bold text-slate-900 dark:text-white">
                Business Platforms
              </h3>

              <p className="mt-4 leading-7 text-slate-600 dark:text-slate-400">
                Custom software solutions built to improve workflows,
                productivity and business operations.
              </p>

              <div className="mt-6 flex flex-wrap gap-2">

                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                  Node.js
                </span>

                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                  PostgreSQL
                </span>

              </div>

            </FloatingCard>

            <FloatingCard
              floating={false}
              className="group p-7"
            >
              <div className="flex items-center justify-between">

                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-50 text-purple-600 dark:bg-purple-500/10 dark:text-purple-400">
                  <Sparkles size={23} />
                </div>

                <ExternalLink
                  size={18}
                  className="text-slate-400 transition group-hover:text-purple-500"
                />

              </div>

              <p className="mt-7 text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                Digital Products
              </p>

              <h3 className="mt-2 text-xl font-bold text-slate-900 dark:text-white">
                Custom Digital Experiences
              </h3>

              <p className="mt-4 leading-7 text-slate-600 dark:text-slate-400">
                Purpose-built products combining thoughtful interfaces with
                dependable engineering.
              </p>

              <div className="mt-6 flex flex-wrap gap-2">

                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                  UI/UX
                </span>

                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                  APIs
                </span>

              </div>

            </FloatingCard>

          </div>
        </Reveal>

        {/* CTA */}
        <Reveal delay={400}>
          <div className="mt-16 text-center">

            <Link
              to="/portfolio"
              className="group inline-flex items-center gap-3 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 px-8 py-4 font-semibold text-white shadow-lg shadow-blue-500/20 transition duration-300 hover:scale-105 hover:shadow-xl hover:shadow-cyan-500/20"
            >
              Explore Portfolio

              <ArrowUpRight
                size={20}
                className="transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1"
              />

            </Link>

          </div>
        </Reveal>

      </div>
    </section>
  );
};

export default PortfolioPreview;