import hero from "../../assets/images/hero.png";

import {
  ArrowRight,
  Globe,
  Smartphone,
  Code2,
  Sparkles,
  Users,
  LifeBuoy,
  Zap,
  ShieldCheck,
  Cloud,
} from "lucide-react";

import { ButtonLink } from "../ui/Button";

import AnimatedBackground from "../effects/AnimatedBackground";
import FloatingCard from "../effects/FloatingCard";
import Reveal from "../effects/Reveal";
import SectionGlow from "../effects/SectionGlow";

const trustBadges = [
  {
    label: "Web",
    icon: Globe,
  },
  {
    label: "Apps",
    icon: Smartphone,
  },
  {
    label: "Software",
    icon: Code2,
  },
  {
    label: "AI",
    icon: Sparkles,
  },
  {
    label: "Internships",
    icon: Users,
  },
  {
    label: "Support",
    icon: LifeBuoy,
  },
];

const floatingCards = [
  {
    label: "Performance",
    icon: Zap,
    position: "-top-5 -left-4 sm:-left-10",
    delay: 0,
  },
  {
    label: "Security",
    icon: ShieldCheck,
    position: "top-1/4 -right-4 sm:-right-10",
    delay: 150,
  },
  {
    label: "AI Powered",
    icon: Sparkles,
    position: "bottom-1/4 -left-4 sm:-left-12",
    delay: 300,
  },
  {
    label: "Cloud Ready",
    icon: Cloud,
    position: "-bottom-5 -right-2 sm:-right-8",
    delay: 450,
  },
];

const Hero = () => {
  return (
    <section className="relative overflow-hidden border-b border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
      
      {/* Animated Background */}
      <AnimatedBackground />

      {/* Background Glow */}
      <SectionGlow
        size={500}
        color="blue"
        className="-right-40 top-1/4 opacity-20"
      />

      <SectionGlow
        size={350}
        color="cyan"
        className="-left-32 bottom-10 opacity-10"
      />

      <div className="relative z-10 mx-auto grid min-h-[calc(100vh-72px)] max-w-7xl items-center gap-16 px-5 py-20 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-24">

        {/* LEFT CONTENT */}
        <div className="max-w-2xl">

          <Reveal>
            <div className="inline-flex items-center gap-2 rounded-full border border-blue-200 bg-blue-50/80 px-4 py-2 backdrop-blur-sm dark:border-cyan-500/20 dark:bg-cyan-500/5">
              <span className="h-2 w-2 animate-pulse rounded-full bg-blue-600 dark:bg-cyan-400" />

              <span className="text-xs font-semibold uppercase tracking-[0.18em] text-blue-700 dark:text-cyan-300">
                Future Ready Digital Solutions
              </span>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <h1 className="mt-7 text-4xl font-bold leading-[1.08] tracking-tight text-slate-950 sm:text-5xl md:text-6xl lg:text-7xl dark:text-white">
              Engineering digital

              <span className="block bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 bg-clip-text text-transparent dark:from-cyan-400 dark:via-blue-400 dark:to-cyan-400">
                products that scale.
              </span>
            </h1>
          </Reveal>

          <Reveal delay={200}>
            <p className="mt-7 max-w-xl text-base leading-7 text-slate-600 sm:text-lg sm:leading-8 dark:text-slate-400">
              SPE Innovations builds websites, applications and software
              systems for businesses that need more than a template.
              We focus on reliable engineering, modern technology and
              solutions built to grow with you.
            </p>
          </Reveal>

          {/* ACTIONS */}
          <Reveal delay={300}>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">

              <ButtonLink
                to="/contact"
                variant="primary"
                className="group w-full shadow-lg shadow-blue-500/20 transition duration-300 hover:scale-[1.02] hover:shadow-blue-500/30 sm:w-auto"
              >
                Let's Build

                <ArrowRight
                  size={17}
                  className="transition-transform duration-300 group-hover:translate-x-1"
                />
              </ButtonLink>

              <ButtonLink
                to="/services"
                variant="outline"
                className="w-full border-slate-300 text-slate-700 transition duration-300 hover:border-blue-500 hover:bg-blue-50 hover:text-blue-600 dark:border-slate-700 dark:text-slate-200 dark:hover:border-cyan-500 dark:hover:bg-cyan-500/5 dark:hover:text-cyan-400 sm:w-auto"
              >
                View Services
              </ButtonLink>

            </div>
          </Reveal>

          {/* TRUST BADGES */}
          <Reveal delay={400}>
            <div className="mt-10 flex flex-wrap gap-3">

              {trustBadges.map((badge) => {
                const Icon = badge.icon;

                return (
                  <div
                    key={badge.label}
                    className="flex items-center gap-2 rounded-full border border-slate-200 bg-white/80 px-3 py-1.5 shadow-sm backdrop-blur-sm transition duration-300 hover:-translate-y-0.5 hover:border-blue-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-900/60 dark:hover:border-cyan-500/30"
                  >
                    <Icon
                      size={14}
                      className="text-blue-600 dark:text-cyan-400"
                    />

                    <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                      {badge.label}
                    </span>
                  </div>
                );
              })}

            </div>
          </Reveal>

        </div>

        {/* RIGHT VISUAL */}
        <Reveal
          delay={250}
          className="relative flex items-center justify-center lg:justify-end"
        >

          <div className="relative w-full max-w-xl">

            {/* Outer Glow */}
            <div className="absolute -inset-6 -z-10 rounded-[2rem] bg-blue-500/5 blur-2xl dark:bg-cyan-500/10" />

            {/* Border */}
            <div className="absolute -inset-4 -z-10 rounded-[2rem] border border-slate-200/80 dark:border-slate-800" />

            <FloatingCard
              floating={false}
              className="overflow-hidden border border-slate-200 bg-white/80 p-4 shadow-2xl backdrop-blur-xl dark:border-slate-800 dark:bg-slate-900/70 sm:p-5"
            >

              <div className="relative overflow-hidden rounded-xl border border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-950">

                <img
                  src={hero}
                  alt="SPE Innovations digital solutions"
                  className="h-auto w-full object-contain"
                />

              </div>

            </FloatingCard>

            {/* FLOATING CARDS */}
            {floatingCards.map((card) => {
              const Icon = card.icon;

              return (
                <Reveal
                  key={card.label}
                  delay={card.delay}
                  className={`absolute ${card.position} hidden sm:block`}
                >

                  <FloatingCard
                    floating
                    className="flex items-center gap-3 border border-slate-200 bg-white/90 px-4 py-3 shadow-xl backdrop-blur-xl dark:border-slate-700 dark:bg-slate-900/80"
                  >

                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-cyan-500/10 dark:text-cyan-400">
                      <Icon size={17} />
                    </div>

                    <span className="whitespace-nowrap text-sm font-semibold text-slate-700 dark:text-slate-200">
                      {card.label}
                    </span>

                  </FloatingCard>

                </Reveal>
              );
            })}

          </div>

        </Reveal>

      </div>

      {/* Bottom Fade */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-white to-transparent dark:from-slate-950" />

    </section>
  );
};

export default Hero;