import {
  ArrowUpRight,
  Mail,
  Phone,
  Sparkles,
  MessageCircle,
} from "lucide-react";
import { Link } from "react-router-dom";

import Reveal from "../effects/Reveal";
import FloatingCard from "../effects/FloatingCard";
import SectionGlow from "../effects/SectionGlow";

const CTA = () => {
  return (
    <section className="relative overflow-hidden border-t border-slate-200 bg-white py-28 dark:border-slate-800 dark:bg-slate-950">
      {/* Section Glow */}
      <SectionGlow
        size={380}
        color="blue"
        className="-left-40 top-10 opacity-15"
      />

      <SectionGlow
        size={320}
        color="cyan"
        className="-right-32 bottom-0 opacity-10"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        <Reveal>
          <FloatingCard
            glow
            floating={false}
            rotate
            intensity={4}
            className="overflow-hidden"
          >
            <div className="grid items-center gap-12 p-8 md:p-12 lg:grid-cols-2 lg:gap-16 lg:p-16">
              {/* Left Content */}
              <div>
                <div className="inline-flex items-center gap-2 rounded-full border border-blue-200 bg-blue-50 px-4 py-2 dark:border-cyan-500/20 dark:bg-cyan-500/5">
                  <Sparkles
                    size={14}
                    className="text-blue-600 dark:text-cyan-400"
                  />

                  <span className="text-xs font-semibold uppercase tracking-[0.2em] text-blue-700 dark:text-cyan-300">
                    SPE Visions
                  </span>
                </div>

                <h2 className="mt-7 text-4xl font-bold leading-tight tracking-tight text-slate-900 md:text-5xl dark:text-white">
                  Ready to transform your
                  <span className="block bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
                    next big idea?
                  </span>
                </h2>

                <p className="mt-7 max-w-xl text-lg leading-8 text-slate-600 dark:text-slate-400">
                  Whether you're launching a startup, improving existing
                  software or building a new digital product, we can help
                  turn your requirements into a practical solution.
                </p>

                {/* Buttons */}
                <div className="mt-10 flex flex-wrap gap-4">
                  <Link
                    to="/contact"
                    className="group inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 px-7 py-3.5 font-semibold text-white transition-all duration-200 hover:scale-[1.02] hover:shadow-lg hover:shadow-blue-500/20"
                  >
                    Start Your Project

                    <ArrowUpRight
                      size={18}
                      className="transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                    />
                  </Link>

                  <Link
                    to="/services"
                    className="inline-flex items-center rounded-xl border border-slate-300 bg-white px-7 py-3.5 font-semibold text-slate-700 transition-all duration-200 hover:border-blue-500 hover:text-blue-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:border-cyan-500 dark:hover:text-cyan-400"
                  >
                    Explore Services
                  </Link>
                </div>
              </div>

              {/* Contact Card */}
              <FloatingCard
                glow
                floating={false}
                rotate={false}
                className="p-8"
              >
                <div className="flex items-center gap-4">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 text-white shadow-lg shadow-blue-500/20">
                    <MessageCircle size={24} />
                  </div>

                  <div>
                    <p className="text-sm font-semibold text-blue-600 dark:text-cyan-400">
                      Let's Connect
                    </p>

                    <h3 className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">
                      Contact Our Team
                    </h3>
                  </div>
                </div>

                <p className="mt-6 leading-7 text-slate-600 dark:text-slate-400">
                  Tell us about your project, requirements or business goals.
                  We'll help you identify the right technical approach.
                </p>

                {/* Contact Details */}
                <div className="mt-8 space-y-5">
                  <a
                    href="mailto:contact@spevisions.in"
                    className="group flex items-center gap-4"
                  >
                    <div className="rounded-xl bg-blue-50 p-3 text-blue-600 transition-transform duration-200 group-hover:scale-105 dark:bg-slate-800 dark:text-cyan-400">
                      <Mail size={20} />
                    </div>

                    <div>
                      <p className="text-xs uppercase tracking-widest text-slate-500 dark:text-slate-500">
                        Email
                      </p>

                      <p className="mt-1 font-semibold text-slate-900 dark:text-white">
                        contact@spevisions.in
                      </p>
                    </div>
                  </a>

                  <a
                    href="tel:+91XXXXXXXXXX"
                    className="group flex items-center gap-4"
                  >
                    <div className="rounded-xl bg-blue-50 p-3 text-blue-600 transition-transform duration-200 group-hover:scale-105 dark:bg-slate-800 dark:text-cyan-400">
                      <Phone size={20} />
                    </div>

                    <div>
                      <p className="text-xs uppercase tracking-widest text-slate-500 dark:text-slate-500">
                        Phone
                      </p>

                      <p className="mt-1 font-semibold text-slate-900 dark:text-white">
                        +91 XXXXX XXXXX
                      </p>
                    </div>
                  </a>
                </div>

                <Link
                  to="/contact"
                  className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-blue-600 transition-all duration-200 hover:gap-3 dark:text-cyan-400"
                >
                  Visit Contact Page

                  <ArrowUpRight size={17} />
                </Link>
              </FloatingCard>
            </div>
          </FloatingCard>
        </Reveal>
      </div>
    </section>
  );
};

export default CTA;