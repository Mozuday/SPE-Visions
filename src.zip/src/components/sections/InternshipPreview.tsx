import {
  BriefcaseBusiness,
  Code2,
  ArrowUpRight,
  Sparkles,
  Users,
  Award,
} from "lucide-react";
import { Link } from "react-router-dom";

import AnimatedBackground from "../effects/AnimatedBackground";
import Reveal from "../effects/Reveal";
import FloatingCard from "../effects/FloatingCard";
import SectionGlow from "../effects/SectionGlow";

const InternshipPreview = () => {
  return (
    <section className="relative overflow-hidden border-b border-slate-200 bg-white py-28 dark:border-slate-800 dark:bg-slate-950">

      {/* Background Effects */}
      <AnimatedBackground />

      <SectionGlow
        size={420}
        color="blue"
        className="-left-32 top-20 opacity-20"
      />

      <SectionGlow
        size={300}
        color="cyan"
        className="-right-24 bottom-10 opacity-10"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6">

        {/* Section Heading */}
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">

            <span className="inline-flex items-center gap-2 rounded-full border border-blue-200 bg-blue-50/70 px-5 py-2 text-sm font-semibold text-blue-700 dark:border-cyan-500/20 dark:bg-cyan-500/5 dark:text-cyan-300">
              <Sparkles size={14} />
              Internship Program
            </span>

            <h2 className="mt-6 text-4xl font-bold tracking-tight text-slate-900 md:text-5xl dark:text-white">
              Learn by Building

              <span className="block bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
                Real Industry Projects
              </span>
            </h2>

            <p className="mt-6 text-lg leading-8 text-slate-600 dark:text-slate-400">
              Gain practical experience, work on meaningful projects,
              improve your technical skills and build a portfolio that
              demonstrates what you can actually do.
            </p>

          </div>
        </Reveal>

        {/* Internship Card */}
        <Reveal delay={200}>
          <FloatingCard
            floating={false}
            className="mt-20 overflow-hidden p-8 md:p-12"
          >

            <div className="grid gap-12 lg:grid-cols-[1fr_auto] lg:items-center">

              {/* Content */}
              <div>

                <div className="flex items-center gap-4">

                  <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-500 text-white shadow-lg shadow-blue-500/20">
                    <BriefcaseBusiness size={30} />
                  </div>

                  <div>

                    <p className="text-sm font-semibold uppercase tracking-wider text-blue-600 dark:text-cyan-400">
                      Start Your Career
                    </p>

                    <h3 className="mt-1 text-2xl font-bold text-slate-900 md:text-3xl dark:text-white">
                      Become an SPE Intern
                    </h3>

                  </div>

                </div>

                <p className="mt-7 max-w-3xl text-lg leading-8 text-slate-600 dark:text-slate-400">
                  Build practical experience through structured internship
                  work, develop real projects, strengthen your portfolio
                  and gain experience that can help prepare you for
                  internships, freelancing and full-time opportunities.
                </p>

                {/* Benefits */}
                <div className="mt-8 grid gap-4 sm:grid-cols-3">

                  <div className="flex items-center gap-3">

                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-cyan-500/10 dark:text-cyan-400">
                      <Users size={18} />
                    </div>

                    <div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        Practical Work
                      </p>

                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Real Projects
                      </p>
                    </div>

                  </div>

                  <div className="flex items-center gap-3">

                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-cyan-500/10 dark:text-cyan-400">
                      <Code2 size={18} />
                    </div>

                    <div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        Development
                      </p>

                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Build Your Skills
                      </p>
                    </div>

                  </div>

                  <div className="flex items-center gap-3">

                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-cyan-500/10 dark:text-cyan-400">
                      <Award size={18} />
                    </div>

                    <div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        Certification
                      </p>

                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        On Completion
                      </p>
                    </div>

                  </div>

                </div>

              </div>

              {/* CTA */}
              <div className="lg:shrink-0">

                <Link
                  to="/internships/apply"
                  className="group inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 px-8 py-4 font-semibold text-white shadow-lg shadow-blue-500/20 transition duration-300 hover:scale-[1.03] hover:shadow-xl hover:shadow-cyan-500/20 lg:w-auto"
                >
                  Apply Now

                  <ArrowUpRight
                    size={20}
                    className="transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1"
                  />
                </Link>

              </div>

            </div>

          </FloatingCard>
        </Reveal>

      </div>

    </section>
  );
};

export default InternshipPreview;