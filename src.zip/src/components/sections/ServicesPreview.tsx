import {
  ArrowUpRight,
  Bug,
  Globe,
  Laptop,
  Smartphone,
  Wrench,
} from "lucide-react";
import { Link } from "react-router-dom";

import SectionTitle from "../ui/SectionTitle";
import FloatingCard from "../effects/FloatingCard";
import Reveal from "../effects/Reveal";
import SectionGlow from "../effects/SectionGlow";
import AnimatedBackground from "../effects/AnimatedBackground";

const services = [
  {
    icon: Globe,
    title: "Website Development",
    description:
      "Responsive and modern websites designed to help businesses establish a professional and effective online presence.",
  },
  {
    icon: Smartphone,
    title: "App Development",
    description:
      "Practical mobile applications designed to provide reliable and engaging experiences across modern devices.",
  },
  {
    icon: Laptop,
    title: "Software Development",
    description:
      "Custom software solutions built around specific business requirements, workflows and operational needs.",
  },
  {
    icon: Bug,
    title: "Bug Fixing",
    description:
      "Debugging, performance optimization and technical maintenance for existing websites and applications.",
  },
  {
    icon: Wrench,
    title: "Technical Consulting",
    description:
      "Technical guidance for selecting technologies, improving architecture and planning scalable digital products.",
  },
];

const ServicesPreview = () => {
  return (
    <section className="relative overflow-hidden border-b border-slate-200 bg-white py-28 dark:border-slate-800 dark:bg-slate-950">

      <AnimatedBackground />

      <SectionGlow
        size={360}
        color="blue"
        className="-left-40 top-16 opacity-20"
      />

      <SectionGlow
        size={300}
        color="cyan"
        className="-right-32 bottom-0 opacity-10"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6">

        <Reveal>
          <SectionTitle
            eyebrow="What We Do"
            title="Technology solutions built around your needs"
            description="From websites and applications to software development and technical support, we help turn ideas and business requirements into practical digital solutions."
          />
        </Reveal>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">

          {services.map((service, index) => {
            const Icon = service.icon;

            return (
              <Reveal
                key={service.title}
                delay={index * 80}
              >
                <FloatingCard
                  glow
                  floating={false}
                  rotate
                  intensity={5}
                  className="group h-full p-7"
                >
                  <div className="flex h-full flex-col">

                    <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 transition-all duration-300 group-hover:border-blue-200 group-hover:bg-blue-50 group-hover:text-blue-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:group-hover:border-cyan-500/30 dark:group-hover:bg-cyan-500/10 dark:group-hover:text-cyan-400">
                      <Icon
                        size={22}
                        strokeWidth={1.8}
                      />
                    </div>

                    <h3 className="mt-7 text-xl font-semibold tracking-tight text-slate-900 dark:text-white">
                      {service.title}
                    </h3>

                    <p className="mt-3 flex-1 text-sm leading-7 text-slate-600 dark:text-slate-400">
                      {service.description}
                    </p>

                    <Link
                      to="/services"
                      className="mt-7 inline-flex w-fit items-center gap-2 text-sm font-semibold text-slate-900 transition-all duration-200 hover:gap-3 hover:text-blue-600 dark:text-white dark:hover:text-cyan-400"
                    >
                      Learn more

                      <ArrowUpRight
                        size={16}
                        className="transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                      />
                    </Link>

                  </div>
                </FloatingCard>
              </Reveal>
            );
          })}

          <Reveal delay={400}>
            <div className="flex h-full min-h-[260px] flex-col justify-between rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-7 transition-all duration-300 hover:border-blue-300 hover:bg-blue-50/40 dark:border-slate-700 dark:bg-slate-900/60 dark:hover:border-cyan-500/30 dark:hover:bg-cyan-500/5">

              <div>

                <p className="text-sm font-semibold text-blue-600 dark:text-cyan-400">
                  Have a project in mind?
                </p>

                <h3 className="mt-3 text-2xl font-semibold tracking-tight text-slate-900 dark:text-white">
                  Let's build something useful.
                </h3>

                <p className="mt-3 text-sm leading-7 text-slate-600 dark:text-slate-400">
                  Tell us what you are trying to build, improve or fix and
                  we will help you find a practical way forward.
                </p>

              </div>

              <Link
                to="/contact"
                className="mt-8 inline-flex w-fit items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition-all duration-200 hover:bg-blue-600 hover:shadow-lg hover:shadow-blue-500/20 dark:bg-white dark:text-slate-950 dark:hover:bg-cyan-500 dark:hover:text-white"
              >
                Start a conversation

                <ArrowUpRight size={16} />
              </Link>

            </div>
          </Reveal>

        </div>
      </div>
    </section>
  );
};

export default ServicesPreview;