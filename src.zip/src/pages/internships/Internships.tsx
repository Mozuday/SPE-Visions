import {
  ArrowRight,
  BriefcaseBusiness,
  CheckCircle,
  Code2,
  Database,
  Monitor,
  Smartphone,
} from "lucide-react";
import { Link } from "react-router-dom";

import AnimatedBackground from "../../components/effects/AnimatedBackground";
import AnimatedButton from "../../components/effects/AnimatedButton";
import FloatingCard from "../../components/effects/FloatingCard";
import Reveal from "../../components/effects/Reveal";
import SectionGlow from "../../components/effects/SectionGlow";

const internships = [
  {
    icon: Monitor,
    title: "Web Design",
    description:
      "Learn modern UI/UX principles and build responsive websites using professional design and development practices.",
    skills: [
      "UI/UX Fundamentals",
      "Responsive Design",
      "HTML & CSS",
      "Tailwind CSS",
    ],
  },
  {
    icon: Code2,
    title: "Frontend Development",
    description:
      "Build modern and interactive user interfaces using React, TypeScript and modern frontend technologies.",
    skills: [
      "HTML & CSS",
      "JavaScript",
      "React",
      "TypeScript",
    ],
  },
  {
    icon: Database,
    title: "Backend Development",
    description:
      "Learn how to build secure APIs, work with databases and develop scalable server-side applications.",
    skills: [
      "Node.js",
      "REST APIs",
      "PostgreSQL",
      "Authentication",
    ],
  },
  {
    icon: Smartphone,
    title: "App Development",
    description:
      "Build modern mobile applications and learn the fundamentals of mobile application development.",
    skills: [
      "Mobile UI",
      "API Integration",
      "Application Development",
      "Deployment",
    ],
  },
];

const Internships = () => {
  return (
    <main className="relative overflow-hidden">

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-white py-28 dark:border-slate-800 dark:bg-slate-950">

        <AnimatedBackground />

        <SectionGlow
          size={380}
          color="blue"
          className="-left-40 top-10 opacity-20"
        />

        <SectionGlow
          size={300}
          color="cyan"
          className="right-[-120px] bottom-[-80px] opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="mx-auto max-w-4xl text-center">

              <span className="inline-flex rounded-full border border-blue-200 bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700 dark:border-blue-900 dark:bg-blue-950/40 dark:text-blue-400">
                Internship Program
              </span>

              <h1 className="mt-7 text-4xl font-bold tracking-tight text-slate-900 md:text-6xl dark:text-white">
                Build Skills Through Real Experience
              </h1>

              <p className="mx-auto mt-6 max-w-3xl text-lg leading-8 text-slate-600 dark:text-slate-300">
                Gain practical experience through real-world projects,
                strengthen your technical skills and build a professional
                portfolio with SPE Visions.
              </p>

              <div className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row">

                <AnimatedButton>
                  <Link
                    to="/internships/apply"
                    className="inline-flex items-center gap-2"
                  >
                    Apply for Internship
                    <ArrowRight size={18} />
                  </Link>
                </AnimatedButton>

                <Link
                  to="#domains"
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-6 py-3 font-semibold text-slate-700 transition hover:border-slate-900 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:border-slate-500 dark:hover:bg-slate-900"
                >
                  Explore Domains
                  <ArrowRight size={17} />
                </Link>

              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Internship Domains */}
      <section
        id="domains"
        className="relative overflow-hidden border-b border-slate-200 bg-slate-50 py-28 dark:border-slate-800 dark:bg-slate-900/40"
      >

        <SectionGlow
          size={320}
          color="purple"
          className="left-[-150px] top-40 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">

          <Reveal>
            <div className="mx-auto max-w-3xl text-center">

              <span className="text-sm font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                Available Domains
              </span>

              <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl dark:text-white">
                Choose Your Learning Path
              </h2>

              <p className="mt-5 text-lg leading-8 text-slate-600 dark:text-slate-300">
                Select an area that matches your interests and start developing
                practical, industry-ready skills.
              </p>

            </div>
          </Reveal>

          <div className="mt-16 grid gap-7 md:grid-cols-2">

            {internships.map((internship, index) => {
              const Icon = internship.icon;

              return (
                <Reveal
                  key={internship.title}
                  delay={index * 100}
                >
                  <FloatingCard
                    className="group h-full p-8 md:p-10"
                    intensity={6}
                  >

                    <div className="relative z-10">

                      {/* Header */}
                      <div className="flex flex-col gap-6 sm:flex-row">

                        <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-blue-200 bg-blue-50 text-blue-600 transition-colors group-hover:border-blue-300 group-hover:bg-blue-100 dark:border-blue-900 dark:bg-blue-950/40 dark:text-blue-400 dark:group-hover:border-blue-800">
                          <Icon size={30} strokeWidth={1.8} />
                        </div>

                        <div>
                          <h3 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                            {internship.title}
                          </h3>

                          <p className="mt-4 leading-7 text-slate-600 dark:text-slate-300">
                            {internship.description}
                          </p>
                        </div>

                      </div>

                      {/* Skills */}
                      <div className="mt-8 border-t border-slate-200 pt-6 dark:border-slate-800">

                        <h4 className="text-sm font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                          Skills You Will Work With
                        </h4>

                        <div className="mt-5 grid gap-3 sm:grid-cols-2">

                          {internship.skills.map((skill) => (
                            <div
                              key={skill}
                              className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"
                            >
                              <CheckCircle
                                size={17}
                                className="shrink-0 text-blue-500"
                              />

                              {skill}
                            </div>
                          ))}

                        </div>
                      </div>

                      {/* Action */}
                      <Link
                        to="/internships/apply"
                        className="mt-8 inline-flex items-center gap-2 font-semibold text-blue-600 transition-all group-hover:gap-3 dark:text-blue-400"
                      >
                        Apply for This Internship
                        <ArrowRight size={18} />
                      </Link>

                    </div>

                  </FloatingCard>
                </Reveal>
              );
            })}

          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="relative overflow-hidden bg-white py-28 dark:bg-slate-950">

        <SectionGlow
          size={340}
          color="cyan"
          className="right-[-160px] top-20 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">

          <Reveal>
            <div className="mx-auto max-w-3xl text-center">

              <span className="text-sm font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                Simple Process
              </span>

              <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl dark:text-white">
                How the Internship Works
              </h2>

              <p className="mt-5 text-lg leading-8 text-slate-600 dark:text-slate-300">
                A simple process designed to help you move from learning to
                practical experience.
              </p>

            </div>
          </Reveal>

          <div className="mt-16 grid gap-7 md:grid-cols-3">

            {[
              {
                number: "01",
                title: "Apply",
                description:
                  "Submit your application and select the internship domain that matches your interests.",
              },
              {
                number: "02",
                title: "Learn & Build",
                description:
                  "Work on practical assignments and projects to improve your technical and professional skills.",
              },
              {
                number: "03",
                title: "Complete & Get Certified",
                description:
                  "Successfully complete the internship requirements and receive your internship completion certificate.",
              },
            ].map((step, index) => (
              <Reveal
                key={step.number}
                delay={index * 100}
              >
                <FloatingCard
                  className="h-full p-8"
                  intensity={5}
                >

                  <span className="text-4xl font-black text-blue-500">
                    {step.number}
                  </span>

                  <h3 className="mt-5 text-xl font-bold text-slate-900 dark:text-white">
                    {step.title}
                  </h3>

                  <p className="mt-4 leading-7 text-slate-600 dark:text-slate-300">
                    {step.description}
                  </p>

                </FloatingCard>
              </Reveal>
            ))}

          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="relative overflow-hidden border-t border-slate-200 bg-slate-50 py-28 dark:border-slate-800 dark:bg-slate-900/40">

        <SectionGlow
          size={360}
          color="blue"
          className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-15"
        />

        <div className="relative z-10 mx-auto max-w-5xl px-6">

          <Reveal>

            <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white p-10 text-center shadow-sm md:p-16 dark:border-slate-800 dark:bg-slate-950">

              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">
                <BriefcaseBusiness size={30} />
              </div>

              <h2 className="mt-7 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl dark:text-white">
                Ready to Start Your Journey?
              </h2>

              <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-slate-600 dark:text-slate-300">
                Take the next step toward building practical skills, gaining
                experience and strengthening your professional portfolio.
              </p>

              <div className="mt-9 flex justify-center">

                <AnimatedButton>
                  <Link
                    to="/internships/apply"
                    className="inline-flex items-center gap-2"
                  >
                    Apply Now
                    <ArrowRight size={18} />
                  </Link>
                </AnimatedButton>

              </div>

            </div>

          </Reveal>

        </div>
      </section>

    </main>
  );
};

export default Internships;