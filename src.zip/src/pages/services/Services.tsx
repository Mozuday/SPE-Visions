import {
  Globe,
  Smartphone,
  Laptop,
  Bug,
  Wrench,
  CheckCircle,
  ArrowRight,
} from "lucide-react";
import { Link } from "react-router-dom";

import AnimatedBackground from "../../components/effects/AnimatedBackground";
import FloatingCard from "../../components/effects/FloatingCard";
import Reveal from "../../components/effects/Reveal";
import SectionGlow from "../../components/effects/SectionGlow";

const services = [
  {
    icon: Globe,
    title: "Website Development",
    description:
      "Professional, responsive and SEO-friendly websites built for businesses, startups and personal brands.",
    features: [
      "Business Websites",
      "Portfolio Websites",
      "E-Commerce",
      "Landing Pages",
    ],
  },
  {
    icon: Smartphone,
    title: "App Development",
    description:
      "Modern mobile applications designed for reliable performance, clean interfaces and excellent user experiences.",
    features: [
      "Android Apps",
      "iOS Apps",
      "React Native",
      "Flutter",
    ],
  },
  {
    icon: Laptop,
    title: "Software Development",
    description:
      "Custom software solutions designed to automate business operations, simplify workflows and improve productivity.",
    features: [
      "Business Software",
      "CRM Systems",
      "ERP Solutions",
      "Automation",
    ],
  },
  {
    icon: Bug,
    title: "Bug Fixing",
    description:
      "Debugging, optimization and maintenance services for existing websites, applications and software systems.",
    features: [
      "Error Fixing",
      "Performance Optimization",
      "Security Fixes",
      "Code Refactoring",
    ],
  },
  {
    icon: Wrench,
    title: "Technical Consulting",
    description:
      "Practical technical guidance to help you choose technologies, improve architecture and plan your digital product.",
    features: [
      "System Architecture",
      "Technology Selection",
      "Code Review",
      "Deployment Guidance",
    ],
  },
];

const Services = () => {
  return (
    <main className="relative overflow-hidden bg-white dark:bg-slate-950">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200 py-24 dark:border-slate-800">
        <AnimatedBackground />

        <SectionGlow
          size={360}
          color="blue"
          className="-left-40 top-10 opacity-20"
        />

        <SectionGlow
          size={320}
          color="cyan"
          className="-right-32 bottom-0 opacity-15"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="mx-auto max-w-4xl text-center">
              <span className="inline-flex rounded-full border border-blue-200 bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700 dark:border-blue-900 dark:bg-blue-950/40 dark:text-blue-300">
                Our Services
              </span>

              <h1 className="mt-6 text-4xl font-bold tracking-tight text-slate-900 md:text-6xl dark:text-white">
                Complete Digital Solutions
              </h1>

              <p className="mx-auto mt-6 max-w-3xl text-lg leading-8 text-slate-600 dark:text-slate-300">
                We help startups, businesses and individuals turn ideas into
                reliable digital products through practical technology,
                thoughtful design and scalable development.
              </p>

              <div className="mt-8 flex flex-col justify-center gap-4 sm:flex-row">
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-7 py-3.5 font-semibold text-white transition duration-300 hover:-translate-y-0.5 hover:bg-blue-600 dark:bg-white dark:text-slate-950 dark:hover:bg-blue-500 dark:hover:text-white"
                >
                  Start a Project
                  <ArrowRight size={18} />
                </Link>

                <Link
                  to="/portfolio"
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-7 py-3.5 font-semibold text-slate-800 transition duration-300 hover:-translate-y-0.5 hover:border-blue-400 hover:text-blue-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:border-blue-500 dark:hover:text-blue-400"
                >
                  View Our Work
                  <ArrowRight size={18} />
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Services */}
      <section className="relative overflow-hidden py-24">
        <SectionGlow
          size={300}
          color="purple"
          className="left-[-150px] top-1/3 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="mx-auto max-w-3xl text-center">
              <span className="text-sm font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                What We Do
              </span>

              <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl dark:text-white">
                Technology Built Around Your Needs
              </h2>

              <p className="mt-5 text-lg leading-8 text-slate-600 dark:text-slate-300">
                From websites and mobile applications to custom software and
                technical support, we provide focused solutions for real
                business requirements.
              </p>
            </div>
          </Reveal>

          <div className="mt-16 grid gap-7">
            {services.map((service, index) => {
              const Icon = service.icon;

              return (
                <Reveal key={service.title} delay={index * 80}>
                  <FloatingCard
                    glow={true}
                    floating={false}
                    rotate={true}
                    intensity={5}
                    className="overflow-hidden p-0"
                  >
                    <article className="group grid gap-8 p-7 md:p-9 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
                      {/* Information */}
                      <div>
                        <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
                          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-blue-100 bg-blue-50 text-blue-600 transition duration-300 group-hover:border-blue-200 group-hover:bg-blue-100 dark:border-blue-900/50 dark:bg-blue-950/40 dark:text-blue-400 dark:group-hover:bg-blue-900/50">
                            <Icon size={27} strokeWidth={1.8} />
                          </div>

                          <div>
                            <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                              {service.title}
                            </h2>

                            <p className="mt-4 max-w-2xl leading-7 text-slate-600 dark:text-slate-300">
                              {service.description}
                            </p>
                          </div>
                        </div>

                        <Link
                          to="/contact"
                          className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-slate-900 transition-all duration-200 hover:gap-3 hover:text-blue-600 dark:text-white dark:hover:text-blue-400"
                        >
                          Discuss Your Project
                          <ArrowRight size={17} />
                        </Link>
                      </div>

                      {/* Features */}
                      <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6 dark:border-slate-800 dark:bg-slate-950/70">
                        <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                          What We Offer
                        </p>

                        <div className="mt-5 grid gap-4 sm:grid-cols-2">
                          {service.features.map((feature) => (
                            <div
                              key={feature}
                              className="flex items-center gap-3"
                            >
                              <CheckCircle
                                size={18}
                                className="shrink-0 text-blue-600 dark:text-blue-400"
                              />

                              <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                                {feature}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </article>
                  </FloatingCard>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="relative overflow-hidden border-y border-slate-200 bg-slate-50 py-24 dark:border-slate-800 dark:bg-slate-900/40">
        <AnimatedBackground />

        <SectionGlow
          size={360}
          color="cyan"
          className="right-[-180px] top-1/2 -translate-y-1/2 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="mx-auto max-w-3xl text-center">
              <span className="text-sm font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                Our Process
              </span>

              <h2 className="mt-3 text-3xl font-bold text-slate-900 md:text-4xl dark:text-white">
                From Idea to Solution
              </h2>

              <p className="mt-5 text-lg leading-8 text-slate-600 dark:text-slate-300">
                A simple and transparent process focused on understanding your
                requirements and delivering useful technology.
              </p>
            </div>
          </Reveal>

          <div className="mt-16 grid gap-6 md:grid-cols-3">
            {[
              {
                number: "01",
                title: "Understand",
                text: "We understand your requirements, goals, users and technical challenges.",
              },
              {
                number: "02",
                title: "Build",
                text: "We design and develop the solution using appropriate technologies and development practices.",
              },
              {
                number: "03",
                title: "Deliver",
                text: "We test, refine and deliver a reliable solution ready for real-world use.",
              },
            ].map((step, index) => (
              <Reveal key={step.number} delay={index * 100}>
                <div className="h-full rounded-2xl border border-slate-200 bg-white p-7 dark:border-slate-800 dark:bg-slate-950">
                  <span className="text-4xl font-black text-blue-600/80 dark:text-blue-400/80">
                    {step.number}
                  </span>

                  <h3 className="mt-5 text-xl font-bold text-slate-900 dark:text-white">
                    {step.title}
                  </h3>

                  <p className="mt-4 leading-7 text-slate-600 dark:text-slate-400">
                    {step.text}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden py-24">
        <SectionGlow
          size={380}
          color="blue"
          className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-15"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="rounded-3xl border border-slate-200 bg-slate-900 p-10 text-center shadow-xl md:p-14 dark:border-slate-800 dark:bg-slate-900">
              <h2 className="text-3xl font-bold text-white md:text-4xl">
                Have a Project in Mind?
              </h2>

              <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-slate-300">
                Tell us what you want to build, improve or fix. We'll help you
                find a practical technology solution.
              </p>

              <Link
                to="/contact"
                className="mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-8 py-4 font-semibold text-slate-900 transition duration-300 hover:-translate-y-0.5 hover:bg-blue-500 hover:text-white"
              >
                Request a Quote
                <ArrowRight size={18} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </main>
  );
};

export default Services;