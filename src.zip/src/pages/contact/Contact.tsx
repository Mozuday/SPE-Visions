import {
  BookOpen,
  Clock3,
  Award,
  ArrowUpRight,
  Sparkles,
} from "lucide-react";
import { Link } from "react-router-dom";

import SectionTitle from "../../components/ui/SectionTitle";
import AnimatedBackground from "../../components/effects/AnimatedBackground";
import Reveal from "../../components/effects/Reveal";
import FloatingCard from "../../components/effects/FloatingCard";
import SectionGlow from "../../components/effects/SectionGlow";

const courses = [
  {
    title: "Full Stack Development",
    duration: "12 Weeks",
    level: "Advanced",
    students: "250+",
    description:
      "Master frontend, backend, databases, APIs and deployment by building complete real-world applications.",
  },
  {
    title: "Frontend Development",
    duration: "6 Weeks",
    level: "Beginner",
    students: "400+",
    description:
      "Build responsive and modern interfaces using HTML, CSS, JavaScript, Tailwind CSS and React.",
  },
  {
    title: "Backend Development",
    duration: "8 Weeks",
    level: "Intermediate",
    students: "180+",
    description:
      "Learn APIs, authentication, databases, security and server-side development through practical projects.",
  },
];

const CoursesPreview = () => {
  return (
    <section className="relative overflow-hidden border-b border-slate-200 bg-white py-28 dark:border-slate-800 dark:bg-slate-950">
      <AnimatedBackground
          showGrid={true}
        showGlow={false}
        showParticles={true}
        showElectricLines={true}
      />

      <SectionGlow
        size={320}
        color="blue"
        className="-left-40 top-20 opacity-20"
      />

      <SectionGlow
        size={280}
        color="cyan"
        className="-right-32 bottom-10 opacity-15"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">

        <Reveal>
          <SectionTitle
            eyebrow="SPE Academy"
            title="Learn skills that companies actually need"
            description="Industry-focused courses designed around practical development, real projects and the technologies developers use every day."
          />
        </Reveal>

        <div className="mt-20 grid gap-7 lg:grid-cols-3">
          {courses.map((course, index) => (
            <Reveal
              key={course.title}
              delay={index * 100}
            >
              <FloatingCard
                glow
                floating
                rotate
                className="group h-full overflow-hidden p-8"
              >
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-blue-500/0 via-cyan-500/0 to-blue-500/10 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                <div className="relative z-10 flex h-full flex-col">

                  <div className="mb-8 flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-900 text-white shadow-lg shadow-slate-900/10 transition-transform duration-300 group-hover:scale-105 dark:bg-white dark:text-slate-950">
                    <BookOpen size={25} strokeWidth={1.8} />
                  </div>

                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-blue-600 dark:text-cyan-400">
                    Professional Course
                  </p>

                  <h3 className="mt-3 text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                    {course.title}
                  </h3>

                  <div className="mt-6 flex flex-wrap gap-2">
                    <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                      <Clock3 size={14} />
                      {course.duration}
                    </span>

                    <span className="rounded-full border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-600 dark:border-cyan-500/20 dark:bg-cyan-500/10 dark:text-cyan-400">
                      {course.level}
                    </span>
                  </div>

                  <p className="mt-6 flex-1 text-sm leading-7 text-slate-600 dark:text-slate-400">
                    {course.description}
                  </p>

                  <div className="mt-8 grid grid-cols-2 gap-3 border-t border-slate-200 pt-6 dark:border-slate-800">

                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <Award size={16} className="text-blue-600 dark:text-cyan-400" />
                      Certificate
                    </div>

                    <div className="flex items-center justify-end gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <Sparkles size={16} className="text-blue-600 dark:text-cyan-400" />
                      {course.students}
                    </div>

                  </div>

                  <Link
                    to="/courses"
                    className="mt-7 inline-flex w-fit items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition-all duration-300 hover:bg-blue-600 hover:shadow-lg hover:shadow-blue-500/20 dark:bg-white dark:text-slate-950 dark:hover:bg-cyan-400"
                  >
                    View Course
                    <ArrowUpRight
                      size={16}
                      className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                    />
                  </Link>

                </div>
              </FloatingCard>
            </Reveal>
          ))}
        </div>

        <Reveal delay={350}>
          <div className="mt-20 rounded-3xl border border-slate-200 bg-slate-50/80 p-8 text-center backdrop-blur-sm sm:p-12 dark:border-slate-800 dark:bg-slate-900/60">

            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-blue-600 shadow-sm dark:bg-slate-800 dark:text-cyan-400">
              <Award size={26} />
            </div>

            <p className="mt-6 text-xs font-semibold uppercase tracking-[0.2em] text-blue-600 dark:text-cyan-400">
              Learn • Build • Grow
            </p>

            <h3 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
              Turn knowledge into practical experience.
            </h3>

            <p className="mx-auto mt-5 max-w-2xl text-sm leading-7 text-slate-600 dark:text-slate-400">
              Learn through projects instead of memorizing theory. Build
              applications, strengthen your portfolio and develop skills that
              can help you prepare for internships, freelance work and full-time
              opportunities.
            </p>

            <Link
              to="/courses"
              className="mt-8 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white transition-all duration-300 hover:bg-blue-600 hover:shadow-lg hover:shadow-blue-500/20 dark:bg-white dark:text-slate-950 dark:hover:bg-cyan-400"
            >
              Explore All Courses
              <ArrowUpRight size={17} />
            </Link>

          </div>
        </Reveal>

      </div>
    </section>
  );
};

export default CoursesPreview;