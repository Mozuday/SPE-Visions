import {
  BookOpen,
  Clock3,
  Award,
  ArrowUpRight,
  Sparkles,
  GraduationCap,
  Users,
  CheckCircle2,
} from "lucide-react";
import { Link } from "react-router-dom";

import SectionTitle from "../../components/ui/SectionTitle";
import AnimatedBackground from "../../components/effects/AnimatedBackground";
import Reveal from "../../components/effects/Reveal";
import FloatingCard from "../../components/effects/FloatingCard";
import SectionGlow from "../../components/effects/SectionGlow";

const courses = [
  {
    title: "Full Stack Development",
    duration: "12 Weeks",
    level: "Advanced",
    students: "250+ Students",
    projects: "15 Projects",
    description:
      "Master frontend, backend, databases, APIs and deployment by building complete real-world applications.",
  },
  {
    title: "Frontend Development",
    duration: "6 Weeks",
    level: "Beginner",
    students: "400+ Students",
    projects: "10 Projects",
    description:
      "Learn HTML, CSS, JavaScript, Tailwind CSS, React and TypeScript while building modern responsive interfaces.",
  },
  {
    title: "Backend Development",
    duration: "8 Weeks",
    level: "Intermediate",
    students: "180+ Students",
    projects: "12 Projects",
    description:
      "Build REST APIs, authentication systems and database-driven applications using modern backend technologies.",
  },
];

const features = [
  "Industry-level projects",
  "Certificate of completion",
  "Portfolio building",
  "Career-focused learning",
];

const CoursesPreview = () => {
  return (
    <section className="relative overflow-hidden border-b border-slate-200 bg-white py-28 dark:border-slate-800 dark:bg-slate-950">
      <AnimatedBackground
        showGrid={true}
        showGlow={false}
        showParticles={true}
        showElectricLines={true}
      />

      <SectionGlow
        size={380}
        color="blue"
        className="-left-40 top-20 opacity-20"
      />

      <SectionGlow
        size={320}
        color="cyan"
        className="-right-32 bottom-20 opacity-15"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6 sm:px-8">
        <Reveal>
          <SectionTitle
            eyebrow="SPE Academy"
            title="Learn skills that companies actually need"
            description="Practical courses designed around real development workflows, modern technologies and projects that help you build a stronger portfolio."
          />
        </Reveal>

        <div className="mt-20 grid gap-8 lg:grid-cols-3">
          {courses.map((course, index) => (
            <Reveal
              key={course.title}
              delay={index * 120}
            >
              <FloatingCard
                glow
                floating
                rotate
                className="group h-full p-8"
              >
                <div className="absolute inset-0 -z-0 rounded-2xl bg-gradient-to-br from-blue-500/0 via-cyan-500/0 to-blue-500/10 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                <div className="relative z-10 flex h-full flex-col">
                  <div className="mb-8 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-500 text-white shadow-lg shadow-blue-500/25">
                    <BookOpen
                      size={26}
                      strokeWidth={1.8}
                    />
                  </div>

                  <h3 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                    {course.title}
                  </h3>

                  <div className="mt-5 flex flex-wrap gap-3">
                    <div className="flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1.5 text-sm text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                      <Clock3 size={15} />
                      {course.duration}
                    </div>

                    <span className="rounded-full bg-blue-500/10 px-3 py-1.5 text-sm font-semibold text-blue-600 dark:text-cyan-400">
                      {course.level}
                    </span>
                  </div>

                  <p className="mt-6 flex-1 text-sm leading-7 text-slate-600 dark:text-slate-400">
                    {course.description}
                  </p>

                  <div className="mt-8 space-y-3">
                    {features.map((feature) => (
                      <div
                        key={feature}
                        className="flex items-center gap-3"
                      >
                        <CheckCircle2
                          size={17}
                          className="shrink-0 text-emerald-500"
                        />

                        <span className="text-sm text-slate-600 dark:text-slate-400">
                          {feature}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 grid grid-cols-2 gap-3">
                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900">
                      <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                        <Users size={15} />
                        <span className="text-xs">
                          Students
                        </span>
                      </div>

                      <p className="mt-2 text-sm font-semibold text-slate-900 dark:text-white">
                        {course.students}
                      </p>
                    </div>

                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Projects
                      </p>

                      <p className="mt-2 text-sm font-semibold text-blue-600 dark:text-cyan-400">
                        {course.projects}
                      </p>
                    </div>
                  </div>

                  <div className="mt-7 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                      <Award size={16} />
                      Certificate Included
                    </div>

                    <Sparkles
                      size={17}
                      className="text-amber-500"
                    />
                  </div>

                  <Link
                    to="/courses"
                    className="mt-8 inline-flex w-fit items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-blue-600 hover:shadow-lg hover:shadow-blue-500/20 dark:bg-white dark:text-slate-950 dark:hover:bg-cyan-500 dark:hover:text-white"
                  >
                    Start Learning
                    <ArrowUpRight size={17} />
                  </Link>
                </div>
              </FloatingCard>
            </Reveal>
          ))}
        </div>

        <Reveal delay={400}>
          <div className="mt-20 rounded-3xl border border-slate-200 bg-slate-50 p-8 dark:border-slate-800 dark:bg-slate-900/50 sm:p-10 lg:p-14">
            <div className="mx-auto max-w-4xl text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-500/20">
                <GraduationCap size={30} />
              </div>

              <h3 className="mt-7 text-3xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
                Learn. Build. Get Certified.
              </h3>

              <p className="mt-5 text-base leading-8 text-slate-600 dark:text-slate-400">
                Stop learning only through theory. Build practical
                applications, strengthen your development skills,
                create portfolio projects and prepare yourself for
                internships, freelancing and full-time opportunities.
              </p>

              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300">
                  <CheckCircle2 size={15} />
                  Project Based
                </span>

                <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300">
                  <Award size={15} />
                  Certification
                </span>

                <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300">
                  <Sparkles size={15} />
                  Career Focused
                </span>
              </div>

              <Link
                to="/courses"
                className="mt-9 inline-flex items-center gap-2 rounded-xl bg-blue-600 px-7 py-3 text-sm font-semibold text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-blue-700 hover:shadow-lg hover:shadow-blue-500/20"
              >
                Explore All Courses
                <ArrowUpRight size={18} />
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default CoursesPreview;