import {
  ArrowRight,
  ExternalLink,
  FolderKanban,
  Code2,
  Layers3,
  Smartphone,
} from "lucide-react";
import { Link } from "react-router-dom";

import AnimatedBackground from "../../components/effects/AnimatedBackground";
import FloatingCard from "../../components/effects/FloatingCard";
import Reveal from "../../components/effects/Reveal";
import SectionGlow from "../../components/effects/SectionGlow";
import AnimatedButton from "../../components/effects/AnimatedButton";

const projects = [
  {
    title: "Portfolio Website",
    category: "Personal Branding",
    description:
      "A modern and responsive portfolio website designed to showcase projects, technical skills and professional experience.",
    technologies: ["React", "TypeScript", "Tailwind CSS"],
    icon: Code2,
  },
  {
    title: "SPE Visions",
    category: "Company Website",
    description:
      "A professional digital platform for software services, internships, certification courses and technology solutions.",
    technologies: ["React", "TypeScript", "Node.js"],
    icon: Layers3,
  },
  {
    title: "Custom Web Application",
    category: "Business Solution",
    description:
      "A scalable web application designed to simplify business workflows, improve productivity and provide a better user experience.",
    technologies: ["React", "Node.js", "PostgreSQL"],
    icon: FolderKanban,
  },
];

const Portfolio = () => {
  return (
    <main className="relative overflow-hidden bg-white dark:bg-slate-950">

      {/* =========================================================
          HERO
      ========================================================= */}

      <section className="relative overflow-hidden border-b border-slate-200 py-28 dark:border-slate-800">

        <AnimatedBackground />

        <SectionGlow
          size={380}
          color="purple"
          className="-left-40 top-10 opacity-20"
        />

        <SectionGlow
          size={320}
          color="blue"
          className="-right-40 bottom-0 opacity-15"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">

          <Reveal>
            <div className="mx-auto max-w-4xl text-center">

              <span className="inline-flex items-center gap-2 rounded-full border border-violet-200 bg-violet-50 px-4 py-2 text-sm font-semibold text-violet-700 dark:border-violet-900/50 dark:bg-violet-950/30 dark:text-violet-300">
                <FolderKanban size={16} />
                Our Portfolio
              </span>

              <h1 className="mt-7 text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl md:text-6xl dark:text-white">
                Projects Built With Purpose
              </h1>

              <p className="mx-auto mt-6 max-w-3xl text-lg leading-8 text-slate-600 dark:text-slate-300">
                Explore some of our digital projects and solutions. We focus
                on building products that are practical, reliable, scalable
                and easy to use.
              </p>

            </div>
          </Reveal>

        </div>
      </section>

      {/* =========================================================
          PROJECTS
      ========================================================= */}

      <section className="relative border-b border-slate-200 py-24 dark:border-slate-800">

        <SectionGlow
          size={300}
          color="cyan"
          className="right-[-120px] top-1/3 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">

          <Reveal>
            <div className="max-w-2xl">

              <p className="text-sm font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                Selected Work
              </p>

              <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
                Digital solutions we have built
              </h2>

              <p className="mt-5 leading-8 text-slate-600 dark:text-slate-400">
                Each project is focused on solving a specific problem while
                maintaining a clean interface, maintainable architecture and
                strong user experience.
              </p>

            </div>
          </Reveal>

          <div className="mt-14 grid gap-8 lg:grid-cols-3">

            {projects.map((project, index) => {
              const Icon = project.icon;

              return (
                <Reveal
                  key={project.title}
                  delay={index * 100}
                >

                  <FloatingCard
                    glow
                    floating={false}
                    rotate
                    intensity={5}
                    className="group h-full overflow-hidden p-0"
                  >

                    {/* Project Visual */}

                    <div className="relative h-60 overflow-hidden border-b border-slate-200 bg-slate-100 dark:border-slate-800 dark:bg-slate-900">

                      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 via-transparent to-violet-500/10 transition duration-500 group-hover:from-blue-500/20 group-hover:to-violet-500/20" />

                      <div className="absolute inset-8 rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-950">

                        <div className="flex h-10 items-center gap-2 border-b border-slate-100 px-4 dark:border-slate-800">

                          <span className="h-2.5 w-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
                          <span className="h-2.5 w-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
                          <span className="h-2.5 w-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />

                        </div>

                        <div className="flex h-[calc(100%-40px)] items-center justify-center">

                          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">

                            <Icon size={27} />

                          </div>

                        </div>

                      </div>

                      <div className="absolute right-6 top-6 rounded-full border border-white/50 bg-white/80 px-3 py-1 text-xs font-semibold text-slate-700 backdrop-blur-md dark:border-slate-700 dark:bg-slate-900/80 dark:text-slate-300">
                        {project.category}
                      </div>

                    </div>

                    {/* Content */}

                    <div className="p-8">

                      <h3 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                        {project.title}
                      </h3>

                      <p className="mt-4 leading-7 text-slate-600 dark:text-slate-400">
                        {project.description}
                      </p>

                      {/* Technologies */}

                      <div className="mt-6 flex flex-wrap gap-2">

                        {project.technologies.map((technology) => (
                          <span
                            key={technology}
                            className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                          >
                            {technology}
                          </span>
                        ))}

                      </div>

                      <button
                        type="button"
                        className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-slate-900 transition-all group-hover:gap-3 group-hover:text-blue-600 dark:text-white dark:group-hover:text-blue-400"
                      >
                        View Project
                        <ExternalLink size={16} />
                      </button>

                    </div>

                  </FloatingCard>

                </Reveal>
              );
            })}

          </div>

        </div>
      </section>

      {/* =========================================================
          APPROACH
      ========================================================= */}

      <section className="relative overflow-hidden bg-slate-50 py-24 dark:bg-slate-900/40">

        <AnimatedBackground />

        <SectionGlow
          size={360}
          color="blue"
          className="left-1/2 top-[-180px] -translate-x-1/2 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">

          <Reveal>
            <div className="mx-auto max-w-3xl text-center">

              <p className="text-sm font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                Our Approach
              </p>

              <h2 className="mt-3 text-3xl font-bold text-slate-900 sm:text-4xl dark:text-white">
                We build with purpose
              </h2>

              <p className="mt-5 leading-8 text-slate-600 dark:text-slate-400">
                Good software is not just about writing code. It should solve
                a real problem, provide a good experience and remain reliable
                as the product grows.
              </p>

            </div>
          </Reveal>

          <div className="mt-14 grid gap-6 md:grid-cols-3">

            {[
              {
                number: "01",
                title: "Understand",
                text: "We first understand the business requirement, users and problem that the product needs to solve.",
              },
              {
                number: "02",
                title: "Build",
                text: "We select suitable technologies and build the solution with maintainability, usability and performance in mind.",
              },
              {
                number: "03",
                title: "Improve",
                text: "We test, refine and improve the product based on real requirements and user feedback.",
              },
            ].map((item, index) => (
              <Reveal
                key={item.number}
                delay={index * 100}
              >

                <div className="h-full rounded-2xl border border-slate-200 bg-white p-8 dark:border-slate-800 dark:bg-slate-950">

                  <span className="text-4xl font-black text-blue-600 dark:text-blue-400">
                    {item.number}
                  </span>

                  <h3 className="mt-5 text-xl font-bold text-slate-900 dark:text-white">
                    {item.title}
                  </h3>

                  <p className="mt-4 leading-7 text-slate-600 dark:text-slate-400">
                    {item.text}
                  </p>

                </div>

              </Reveal>
            ))}

          </div>

        </div>
      </section>

      {/* =========================================================
          CTA
      ========================================================= */}

      <section className="relative overflow-hidden py-24">

        <SectionGlow
          size={400}
          color="purple"
          className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">

          <Reveal>

            <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-950 p-10 text-center shadow-xl md:p-16 dark:border-slate-800">

              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 text-white">
                <Smartphone size={30} />
              </div>

              <h2 className="mt-6 text-3xl font-bold text-white md:text-4xl">
                Have an idea for your next project?
              </h2>

              <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-slate-300">
                Tell us what you want to build, improve or fix. We can help
                turn your requirements into a practical digital solution.
              </p>

              <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">

                <AnimatedButton>
                  <Link
                    to="/contact"
                    className="inline-flex items-center gap-2"
                  >
                    Start a Project
                    <ArrowRight size={18} />
                  </Link>
                </AnimatedButton>

                <Link
                  to="/services"
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-700 px-6 py-3 font-semibold text-white transition hover:border-slate-500 hover:bg-white/5"
                >
                  View Services
                </Link>

              </div>

            </div>

          </Reveal>

        </div>
      </section>

    </main>
  );
};

export default Portfolio;