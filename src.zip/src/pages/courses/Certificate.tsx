import { useState } from "react";
import {
  Award,
  CheckCircle,
  Search,
  ShieldCheck,
  ArrowRight,
  Sparkles,
} from "lucide-react";

import AnimatedBackground from "../../components/effects/AnimatedBackground";
import Reveal from "../../components/effects/Reveal";
import FloatingCard from "../../components/effects/FloatingCard";
import SectionGlow from "../../components/effects/SectionGlow";

type CertificateData = {
  certificateId: string;
  studentName: string;
  courseName: string;
  issueDate: string;
  status: "Valid" | "Invalid";
};

const certificates: CertificateData[] = [
  {
    certificateId: "SPE-FSWD-2026-001",
    studentName: "Demo Student",
    courseName: "Full Stack Web Development",
    issueDate: "24 July 2026",
    status: "Valid",
  },
];

const Certificate = () => {
  const [certificateId, setCertificateId] = useState("");
  const [certificate, setCertificate] =
    useState<CertificateData | null>(null);
  const [searched, setSearched] = useState(false);

  const handleVerify = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const normalizedId = certificateId.trim().toUpperCase();

    if (!normalizedId) {
      setCertificate(null);
      setSearched(false);
      return;
    }

    const result = certificates.find(
      (item) => item.certificateId.toUpperCase() === normalizedId
    );

    setCertificate(result ?? null);
    setSearched(true);
  };

  return (
    <main className="relative overflow-hidden bg-white dark:bg-slate-950">

      {/* Hero */}
      <section className="relative min-h-[520px] overflow-hidden border-b border-slate-200 dark:border-slate-800">
        <AnimatedBackground />

        <SectionGlow
          size={420}
          color="blue"
          className="-right-32 top-10 opacity-20"
        />

        <SectionGlow
          size={300}
          color="cyan"
          className="-left-32 bottom-0 opacity-15"
        />

        <div className="relative z-10 mx-auto flex max-w-5xl flex-col items-center px-6 py-28 text-center">

          <Reveal>
            <div className="relative flex h-20 w-20 items-center justify-center rounded-3xl border border-cyan-200 bg-cyan-50 text-cyan-600 shadow-xl shadow-cyan-500/10 dark:border-cyan-900/50 dark:bg-cyan-950/30 dark:text-cyan-400">
              <Award size={40} strokeWidth={1.8} />

              <span className="absolute -right-2 -top-2 flex h-7 w-7 items-center justify-center rounded-full border-4 border-white bg-blue-600 text-white dark:border-slate-950">
                <CheckCircle size={14} />
              </span>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <p className="mt-8 text-sm font-semibold uppercase tracking-[0.2em] text-cyan-600 dark:text-cyan-400">
              SPE Visions
            </p>
          </Reveal>

          <Reveal delay={180}>
            <h1 className="mt-4 text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl md:text-6xl dark:text-white">
              Certificate Verification
            </h1>
          </Reveal>

          <Reveal delay={260}>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-8 text-slate-600 sm:text-lg dark:text-slate-400">
              Verify the authenticity of a certificate issued by SPE Visions
              using its unique certificate identification number.
            </p>
          </Reveal>

          <Reveal delay={340}>
            <div className="mt-8 flex items-center gap-2 text-sm text-slate-500 dark:text-slate-500">
              <ShieldCheck size={17} className="text-green-500" />
              Secure certificate verification
            </div>
          </Reveal>

        </div>
      </section>

      {/* Verification */}
      <section className="relative overflow-hidden py-24">
        <SectionGlow
          size={360}
          color="cyan"
          className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-3xl px-6">

          <Reveal>
            <FloatingCard
              floating={false}
              rotate={false}
              className="p-8 sm:p-10"
            >
              <div className="text-center">

                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-green-50 text-green-600 dark:bg-green-950/30 dark:text-green-400">
                  <ShieldCheck size={30} />
                </div>

                <h2 className="mt-6 text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                  Verify Your Certificate
                </h2>

                <p className="mt-3 text-sm leading-7 text-slate-600 dark:text-slate-400">
                  Enter the certificate ID exactly as it appears on your
                  certificate.
                </p>

              </div>

              <form
                onSubmit={handleVerify}
                className="mt-8 flex flex-col gap-3 sm:flex-row"
              >
                <div className="relative flex-1">
                  <Search
                    size={18}
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
                  />

                  <input
                    type="text"
                    value={certificateId}
                    onChange={(event) =>
                      setCertificateId(event.target.value)
                    }
                    placeholder="SPE-FSWD-2026-001"
                    className="h-12 w-full rounded-xl border border-slate-200 bg-slate-50 pl-11 pr-4 text-sm font-medium text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:ring-4 focus:ring-green-500/10 dark:border-slate-800 dark:bg-slate-950 dark:text-white dark:focus:bg-slate-900"
                  />
                </div>

                <button
                  type="submit"
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-slate-900 px-7 text-sm font-semibold text-white transition duration-300 hover:bg-green-600 hover:shadow-lg hover:shadow-green-500/20 dark:bg-white dark:text-slate-950 dark:hover:bg-green-500 dark:hover:text-white"
                >
                  <Search size={17} />
                  Verify Certificate
                </button>
              </form>

              <p className="mt-4 text-center text-xs text-slate-500 dark:text-slate-500">
                Example: SPE-FSWD-2026-001
              </p>
            </FloatingCard>
          </Reveal>

        </div>
      </section>

      {/* Result */}
      {searched && (
        <section className="relative pb-24">
          <div className="mx-auto max-w-3xl px-6">

            {certificate ? (
              <Reveal>
                <FloatingCard
                  floating={false}
                  rotate={false}
                  glow={false}
                  className="overflow-hidden p-0"
                >

                  <div className="relative overflow-hidden bg-green-600 px-8 py-10 text-center text-white">
                    <div className="absolute inset-0 bg-gradient-to-br from-green-500 via-green-600 to-emerald-700" />

                    <div className="relative z-10">
                      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-white/15 backdrop-blur-sm">
                        <CheckCircle size={38} />
                      </div>

                      <h2 className="mt-5 text-2xl font-bold">
                        Certificate Verified
                      </h2>

                      <p className="mt-2 text-sm text-green-100">
                        This certificate is valid and was issued by SPE
                        Visions.
                      </p>
                    </div>
                  </div>

                  <div className="p-8 sm:p-10">

                    <div className="grid gap-6 sm:grid-cols-2">

                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                          Certificate ID
                        </p>

                        <p className="mt-2 break-all font-semibold text-slate-900 dark:text-white">
                          {certificate.certificateId}
                        </p>
                      </div>

                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                          Verification Status
                        </p>

                        <div className="mt-2 inline-flex items-center gap-2 font-semibold text-green-600 dark:text-green-400">
                          <CheckCircle size={16} />
                          {certificate.status}
                        </div>
                      </div>

                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                          Student Name
                        </p>

                        <p className="mt-2 font-semibold text-slate-900 dark:text-white">
                          {certificate.studentName}
                        </p>
                      </div>

                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                          Issue Date
                        </p>

                        <p className="mt-2 font-semibold text-slate-900 dark:text-white">
                          {certificate.issueDate}
                        </p>
                      </div>

                    </div>

                    <div className="mt-8 rounded-2xl border border-slate-200 bg-slate-50 p-6 dark:border-slate-800 dark:bg-slate-900">
                      <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                        Course Completed
                      </p>

                      <h3 className="mt-3 text-xl font-bold text-slate-900 dark:text-white">
                        {certificate.courseName}
                      </h3>
                    </div>

                  </div>

                </FloatingCard>
              </Reveal>
            ) : (
              <Reveal>
                <div className="rounded-3xl border border-red-200 bg-red-50 p-8 text-center dark:border-red-900/50 dark:bg-red-950/20">

                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-red-100 text-red-600 dark:bg-red-950/50 dark:text-red-400">
                    <Search size={26} />
                  </div>

                  <h2 className="mt-5 text-2xl font-bold text-red-700 dark:text-red-400">
                    Certificate Not Found
                  </h2>

                  <p className="mx-auto mt-3 max-w-xl text-sm leading-7 text-red-600 dark:text-red-300">
                    We could not find a certificate matching the provided ID.
                    Please check the certificate number and try again.
                  </p>

                </div>
              </Reveal>
            )}

          </div>
        </section>
      )}

      {/* Information */}
      <section className="relative overflow-hidden border-t border-slate-200 bg-slate-50 py-24 dark:border-slate-800 dark:bg-slate-900/40">

        <AnimatedBackground />

        <div className="relative z-10 mx-auto max-w-7xl px-6">

          <Reveal>
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-blue-600 dark:text-cyan-400">
                Verification Process
              </p>

              <h2 className="mt-4 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
                Simple, transparent and easy to verify
              </h2>

              <p className="mt-4 text-base leading-7 text-slate-600 dark:text-slate-400">
                Certificate verification helps students, employers and
                organizations confirm the authenticity of issued credentials.
              </p>
            </div>
          </Reveal>

          <div className="mt-14 grid gap-6 md:grid-cols-3">

            <Reveal delay={100}>
              <FloatingCard
                floating={false}
                rotate={false}
                className="h-full p-7"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-50 text-green-600 dark:bg-green-950/30 dark:text-green-400">
                  <ShieldCheck size={24} />
                </div>

                <h3 className="mt-6 text-xl font-bold text-slate-900 dark:text-white">
                  Authentic Certificates
                </h3>

                <p className="mt-4 text-sm leading-7 text-slate-600 dark:text-slate-400">
                  Certificates issued by SPE Visions can be verified using
                  their unique certificate identification number.
                </p>
              </FloatingCard>
            </Reveal>

            <Reveal delay={180}>
              <FloatingCard
                floating={false}
                rotate={false}
                className="h-full p-7"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/30 dark:text-blue-400">
                  <Award size={24} />
                </div>

                <h3 className="mt-6 text-xl font-bold text-slate-900 dark:text-white">
                  Course Completion
                </h3>

                <p className="mt-4 text-sm leading-7 text-slate-600 dark:text-slate-400">
                  Certificates are issued to eligible students after
                  successfully completing the required course requirements.
                </p>
              </FloatingCard>
            </Reveal>

            <Reveal delay={260}>
              <FloatingCard
                floating={false}
                rotate={false}
                className="h-full p-7"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-50 text-cyan-600 dark:bg-cyan-950/30 dark:text-cyan-400">
                  <Sparkles size={24} />
                </div>

                <h3 className="mt-6 text-xl font-bold text-slate-900 dark:text-white">
                  Easy Verification
                </h3>

                <p className="mt-4 text-sm leading-7 text-slate-600 dark:text-slate-400">
                  Students, employers and organizations can quickly verify
                  certificate information using the certificate ID.
                </p>
              </FloatingCard>
            </Reveal>

          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="relative overflow-hidden bg-slate-950 py-24 text-white dark:bg-black">

        <SectionGlow
          size={400}
          color="cyan"
          className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-15"
        />

        <div className="relative z-10 mx-auto max-w-3xl px-6 text-center">

          <Reveal>
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-cyan-400">
              <Award size={28} />
            </div>

            <h2 className="mt-6 text-3xl font-bold tracking-tight sm:text-4xl">
              Looking to build your skills?
            </h2>

            <p className="mx-auto mt-5 max-w-xl leading-7 text-slate-400">
              Explore practical courses and start building projects that can
              strengthen your technical skills and portfolio.
            </p>

            <a
              href="/courses"
              className="mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400"
            >
              Explore Courses
              <ArrowRight size={17} />
            </a>
          </Reveal>

        </div>
      </section>

    </main>
  );
};

export default Certificate;