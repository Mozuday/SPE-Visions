import { useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  CheckCircle,
  Clock3,
  Code2,
  Database,
  Globe,
  Lock,
} from "lucide-react";

import AnimatedBackground from "../../components/effects/AnimatedBackground";
import FloatingCard from "../../components/effects/FloatingCard";
import Reveal from "../../components/effects/Reveal";
import SectionGlow from "../../components/effects/SectionGlow";

const courses = [
  {
    id: "full-stack-web-development",
    icon: Code2,
    title: "Full Stack Web Development",
    duration: "12 Weeks",
    level: "Beginner to Advanced",
    price: "₹4,999",
    description:
      "Learn frontend and backend development by building real-world web applications using modern technologies.",
    technologies: [
      "HTML",
      "CSS",
      "JavaScript",
      "React",
      "TypeScript",
      "Node.js",
      "Express",
      "PostgreSQL",
    ],
    modules: [
      "HTML and CSS Fundamentals",
      "JavaScript Programming",
      "React and TypeScript",
      "Frontend Application Development",
      "Node.js and Express",
      "REST API Development",
      "PostgreSQL and Database Design",
      "Authentication and Security",
      "Deployment and Production",
      "Final Full Stack Project",
    ],
  },
  {
    id: "frontend-development",
    icon: Globe,
    title: "Frontend Development",
    duration: "6 Weeks",
    level: "Beginner",
    price: "₹2,499",
    description:
      "Master responsive user interface development and learn how to build modern websites and applications.",
    technologies: [
      "HTML",
      "CSS",
      "JavaScript",
      "React",
      "TypeScript",
      "Tailwind CSS",
    ],
    modules: [
      "HTML Fundamentals",
      "CSS and Responsive Design",
      "JavaScript Fundamentals",
      "Modern JavaScript",
      "React Fundamentals",
      "React Components and State",
      "TypeScript Basics",
      "Tailwind CSS",
      "API Integration",
      "Final Frontend Project",
    ],
  },
  {
    id: "backend-development",
    icon: Database,
    title: "Backend Development",
    duration: "8 Weeks",
    level: "Intermediate",
    price: "₹3,499",
    description:
      "Learn how to build secure REST APIs, work with databases and create scalable backend applications.",
    technologies: [
      "Node.js",
      "Express",
      "REST APIs",
      "PostgreSQL",
      "Authentication",
    ],
    modules: [
      "Node.js Fundamentals",
      "Express.js",
      "REST API Architecture",
      "PostgreSQL",
      "Database Relationships",
      "Authentication",
      "Authorization",
      "API Security",
      "Deployment",
      "Final Backend Project",
    ],
  },
];

const CourseDetails = () => {
  const { courseId } = useParams<{ courseId: string }>();

  const course = useMemo(
    () => courses.find((item) => item.id === courseId),
    [courseId]
  );

  if (!course) {
    return (
      <main className="relative min-h-[80vh] overflow-hidden bg-slate-50 py-24 dark:bg-slate-950">
        <AnimatedBackground />

        <SectionGlow
          size={360}
          color="blue"
          className="-left-32 top-20 opacity-15"
        />

        <div className="relative z-10 mx-auto max-w-2xl px-6">
          <Reveal>
            <div className="rounded-3xl border border-slate-200 bg-white p-10 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">
                <BookOpen size={30} />
              </div>

              <h1 className="mt-6 text-3xl font-bold text-slate-900 dark:text-white">
                Course Not Found
              </h1>

              <p className="mt-4 leading-7 text-slate-600 dark:text-slate-400">
                The course you are looking for does not exist or may have been
                removed.
              </p>

              <Link
                to="/courses"
                className="mt-8 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-7 py-3 font-semibold text-white transition hover:bg-blue-600 dark:bg-white dark:text-slate-950 dark:hover:bg-blue-500 dark:hover:text-white"
              >
                <ArrowLeft size={18} />
                Back to Courses
              </Link>
            </div>
          </Reveal>
        </div>
      </main>
    );
  }

  const Icon = course.icon;

  return (
    <main className="relative overflow-hidden bg-white dark:bg-slate-950">
      {/* =========================================================
          HERO
      ========================================================= */}

      <section className="relative overflow-hidden border-b border-slate-200 bg-slate-50 py-20 dark:border-slate-800 dark:bg-slate-900/40">
        <AnimatedBackground />

        <SectionGlow
          size={420}
          color="blue"
          className="-right-40 top-0 opacity-15"
        />

        <SectionGlow
          size={300}
          color="cyan"
          className="-left-32 bottom-0 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <Link
              to="/courses"
              className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 transition hover:text-blue-600 dark:text-slate-400 dark:hover:text-cyan-400"
            >
              <ArrowLeft size={17} />
              Back to Courses
            </Link>
          </Reveal>

          <div className="mt-12 grid items-center gap-12 lg:grid-cols-[1fr_380px]">
            {/* Course Information */}

            <Reveal>
              <div>
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-blue-200 bg-blue-50 text-blue-600 dark:border-blue-900 dark:bg-blue-950/40 dark:text-cyan-400">
                  <Icon size={32} />
                </div>

                <p className="mt-7 text-sm font-semibold uppercase tracking-[0.18em] text-blue-600 dark:text-cyan-400">
                  SPE Academy
                </p>

                <h1 className="mt-3 max-w-4xl text-4xl font-bold tracking-tight text-slate-900 md:text-6xl dark:text-white">
                  {course.title}
                </h1>

                <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-600 dark:text-slate-400">
                  {course.description}
                </p>

                <div className="mt-8 flex flex-wrap gap-4">
                  <div className="flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
                    <Clock3 size={17} />
                    {course.duration}
                  </div>

                  <div className="rounded-full border border-blue-200 bg-blue-50 px-4 py-2 text-sm font-medium text-blue-700 dark:border-blue-900 dark:bg-blue-950/40 dark:text-cyan-400">
                    {course.level}
                  </div>
                </div>
              </div>
            </Reveal>

            {/* Enrollment */}

            <Reveal delay={150}>
              <FloatingCard
                rotate={false}
                floating={false}
                className="p-8"
              >
                <p className="text-sm font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                  Course Fee
                </p>

                <p className="mt-3 text-4xl font-black tracking-tight text-slate-900 dark:text-white">
                  {course.price}
                </p>

                <p className="mt-3 text-sm leading-6 text-slate-500 dark:text-slate-400">
                  Get access to the complete course content after enrollment.
                </p>

                <button
                  type="button"
                  className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-6 py-4 font-semibold text-white transition hover:bg-blue-600 dark:bg-white dark:text-slate-950 dark:hover:bg-cyan-400"
                >
                  Enroll Now
                  <ArrowRight size={18} />
                </button>

                <p className="mt-4 text-center text-xs text-slate-500 dark:text-slate-500">
                  Secure payment and course access
                </p>
              </FloatingCard>
            </Reveal>
          </div>
        </div>
      </section>

      {/* =========================================================
          CURRICULUM
      ========================================================= */}

      <section className="relative overflow-hidden border-b border-slate-200 py-24 dark:border-slate-800">
        <SectionGlow
          size={320}
          color="cyan"
          className="-left-40 top-32 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <div className="grid gap-12 lg:grid-cols-[1fr_380px]">
            {/* Modules */}

            <Reveal>
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.18em] text-blue-600 dark:text-cyan-400">
                  Learning Path
                </p>

                <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
                  Course Curriculum
                </h2>

                <p className="mt-4 max-w-2xl text-lg leading-8 text-slate-600 dark:text-slate-400">
                  Follow a structured learning path from fundamentals to
                  practical project development.
                </p>

                <div className="mt-10 space-y-4">
                  {course.modules.map((module, index) => (
                    <div
                      key={module}
                      className="group flex items-center gap-5 rounded-2xl border border-slate-200 bg-white p-5 transition hover:border-blue-200 hover:shadow-md dark:border-slate-800 dark:bg-slate-900 dark:hover:border-blue-900"
                    >
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-50 text-sm font-bold text-blue-600 dark:bg-blue-950/40 dark:text-cyan-400">
                        {String(index + 1).padStart(2, "0")}
                      </div>

                      <div className="flex-1">
                        <h3 className="font-semibold text-slate-900 dark:text-white">
                          {module}
                        </h3>
                      </div>

                      <Lock
                        size={18}
                        className="text-slate-400 transition group-hover:text-blue-500"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>

            {/* What You Get */}

            <Reveal delay={150}>
              <FloatingCard
                rotate={false}
                floating={false}
                className="h-fit p-8"
              >
                <p className="text-sm font-semibold uppercase tracking-[0.18em] text-blue-600 dark:text-cyan-400">
                  Included
                </p>

                <h2 className="mt-3 text-2xl font-bold text-slate-900 dark:text-white">
                  What You Get
                </h2>

                <div className="mt-7 space-y-5">
                  {[
                    "Complete course content",
                    "Practical project-based learning",
                    "Access to course videos",
                    "Course completion certificate",
                  ].map((item) => (
                    <div key={item} className="flex gap-3">
                      <CheckCircle
                        className="shrink-0 text-cyan-500"
                        size={21}
                      />

                      <span className="text-slate-700 dark:text-slate-300">
                        {item}
                      </span>
                    </div>
                  ))}
                </div>
              </FloatingCard>
            </Reveal>
          </div>
        </div>
      </section>

      {/* =========================================================
          TECHNOLOGIES
      ========================================================= */}

      <section className="relative overflow-hidden bg-slate-50 py-24 dark:bg-slate-900/40">
        <AnimatedBackground
          showGrid={false}
          showGlow={false}
          showParticles={true}
          showElectricLines={false}
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6 text-center">
          <Reveal>
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-blue-600 dark:text-cyan-400">
              Technology Stack
            </p>

            <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              Technologies You Will Learn
            </h2>

            <p className="mx-auto mt-4 max-w-2xl leading-7 text-slate-600 dark:text-slate-400">
              Work with technologies used to build modern, scalable digital
              products.
            </p>

            <div className="mx-auto mt-10 flex max-w-4xl flex-wrap justify-center gap-3">
              {course.technologies.map((technology) => (
                <span
                  key={technology}
                  className="rounded-full border border-slate-200 bg-white px-5 py-3 text-sm font-medium text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:border-blue-300 hover:text-blue-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:border-cyan-800 dark:hover:text-cyan-400"
                >
                  {technology}
                </span>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* =========================================================
          FINAL CTA
      ========================================================= */}

      <section className="relative overflow-hidden py-24">
        <SectionGlow
          size={420}
          color="blue"
          className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-15"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-950 p-10 text-center shadow-2xl md:p-16 dark:border-slate-800">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-500/30">
                <BookOpen size={32} />
              </div>

              <h2 className="mt-6 text-3xl font-bold text-white md:text-4xl">
                Start Learning Today
              </h2>

              <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-slate-300">
                Enroll in this course and start building practical skills that
                can help you grow your technology career.
              </p>

              <button
                type="button"
                className="mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-8 py-4 font-semibold text-slate-900 transition hover:scale-105 hover:bg-cyan-400"
              >
                Enroll Now
                <ArrowRight size={18} />
              </button>
            </div>
          </Reveal>
        </div>
      </section>
    </main>
  );
};

export default CourseDetails;