import {
  ArrowRight,
  BookOpen,
  Clock3,
  Code2,
  Database,
  Globe,
  Award,
  CheckCircle2,
} from "lucide-react";
import { Link } from "react-router-dom";

import AnimatedBackground from "../../components/effects/AnimatedBackground";
import FloatingCard from "../../components/effects/FloatingCard";
import Reveal from "../../components/effects/Reveal";
import SectionGlow from "../../components/effects/SectionGlow";
import AnimatedButton from "../../components/effects/AnimatedButton";

const courses = [
  {
    id: "full-stack-web-development",
    icon: Code2,
    title: "Full Stack Web Development",
    duration: "12 Weeks",
    level: "Beginner to Advanced",
    description:
      "Learn how modern web applications are designed, developed, connected to databases and deployed to production.",
    technologies: [
      "HTML",
      "CSS",
      "JavaScript",
      "React",
      "Node.js",
      "PostgreSQL",
    ],
  },
  {
    id: "frontend-development",
    icon: Globe,
    title: "Frontend Development",
    duration: "6 Weeks",
    level: "Beginner",
    description:
      "Learn how to create responsive, accessible and modern interfaces using today's most important frontend technologies.",
    technologies: [
      "HTML",
      "CSS",
      "JavaScript",
      "React",
      "Tailwind CSS",
    ],
  },
  {
    id: "backend-development",
    icon: Database,
    title: "Backend Development",
    duration: "8 Weeks",
    level: "Intermediate",
    description:
      "Understand APIs, databases, authentication and server-side architecture while building practical backend systems.",
    technologies: [
      "Node.js",
      "Express",
      "REST APIs",
      "PostgreSQL",
      "Authentication",
    ],
  },
];

const Courses = () => {
  return (
    <main className="relative overflow-hidden bg-white dark:bg-slate-950">
      {/* =========================================================
          HERO
      ========================================================= */}

      <section className="relative overflow-hidden border-b border-slate-200 py-28 dark:border-slate-800">
        <AnimatedBackground
          showGrid
          showGlow
          showParticles
          showElectricLines
        />

        <SectionGlow
          size={420}
          color="blue"
          className="-left-40 top-10 opacity-20"
        />

        <SectionGlow
          size={360}
          color="cyan"
          className="-right-32 bottom-0 opacity-15"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="mx-auto max-w-4xl text-center">
              <div className="inline-flex items-center gap-2 rounded-full border border-blue-200 bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700 dark:border-blue-900/60 dark:bg-blue-950/30 dark:text-blue-400">
                <BookOpen size={16} />
                SPE Academy
              </div>

              <h1 className="mt-7 text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl md:text-6xl dark:text-white">
                Learn skills that{" "}
                <span className="text-blue-600 dark:text-cyan-400">
                  build careers
                </span>
              </h1>

              <p className="mx-auto mt-6 max-w-3xl text-lg leading-8 text-slate-600 dark:text-slate-400">
                Practical technology courses designed for students,
                freshers and aspiring developers who want to learn by
                building real projects.
              </p>

              <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <AnimatedButton>
                  <Link
                    to="#courses"
                    className="inline-flex items-center gap-2"
                  >
                    Explore Courses
                    <ArrowRight size={17} />
                  </Link>
                </AnimatedButton>

                <Link
                  to="/certificate"
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-slate-800 transition hover:border-blue-400 hover:text-blue-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:border-cyan-500 dark:hover:text-cyan-400"
                >
                  <Award size={17} />
                  Verify Certificate
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* =========================================================
          COURSES
      ========================================================= */}

      <section
        id="courses"
        className="relative overflow-hidden border-b border-slate-200 py-28 dark:border-slate-800"
      >
        <SectionGlow
          size={380}
          color="purple"
          className="right-[-180px] top-20 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="mx-auto max-w-3xl text-center">
              <span className="text-sm font-semibold uppercase tracking-wider text-blue-600 dark:text-cyan-400">
                Available Courses
              </span>

              <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
                Choose your learning path
              </h2>

              <p className="mt-5 text-lg leading-8 text-slate-600 dark:text-slate-400">
                Start with the area you want to learn and develop practical
                skills through structured, project-focused learning.
              </p>
            </div>
          </Reveal>

          <div className="mt-16 grid gap-7 lg:grid-cols-3">
            {courses.map((course, index) => {
              const Icon = course.icon;

              return (
                <Reveal
                  key={course.id}
                  delay={index * 120}
                >
                  <FloatingCard
                    floating={false}
                    rotate={true}
                    glow={true}
                    className="group h-full p-8"
                  >
                    <div className="flex h-full flex-col">
                      {/* Icon */}
                      <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-blue-200 bg-blue-50 text-blue-600 transition-all duration-300 group-hover:scale-105 group-hover:border-cyan-300 group-hover:bg-cyan-50 dark:border-blue-900/60 dark:bg-blue-950/30 dark:text-cyan-400 dark:group-hover:border-cyan-800 dark:group-hover:bg-cyan-950/30">
                        <Icon size={26} />
                      </div>

                      {/* Title */}
                      <h3 className="mt-7 text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                        {course.title}
                      </h3>

                      {/* Meta */}
                      <div className="mt-5 flex flex-wrap gap-3">
                        <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1.5 text-xs font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                          <Clock3 size={14} />
                          {course.duration}
                        </span>

                        <span className="rounded-full bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700 dark:bg-blue-950/30 dark:text-cyan-400">
                          {course.level}
                        </span>
                      </div>

                      {/* Description */}
                      <p className="mt-6 flex-1 text-sm leading-7 text-slate-600 dark:text-slate-400">
                        {course.description}
                      </p>

                      {/* Technologies */}
                      <div className="mt-7">
                        <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-500">
                          Technologies
                        </p>

                        <div className="mt-3 flex flex-wrap gap-2">
                          {course.technologies.map((technology) => (
                            <span
                              key={technology}
                              className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                            >
                              {technology}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Action */}
                      <Link
                        to={`/courses/${course.id}`}
                        className="mt-8 inline-flex w-fit items-center gap-2 text-sm font-semibold text-slate-900 transition-all group-hover:gap-3 group-hover:text-blue-600 dark:text-white dark:group-hover:text-cyan-400"
                      >
                        View Course
                        <ArrowRight size={17} />
                      </Link>
                    </div>
                  </FloatingCard>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* =========================================================
          LEARNING PROCESS
      ========================================================= */}

      <section className="relative overflow-hidden border-b border-slate-200 bg-slate-50 py-28 dark:border-slate-800 dark:bg-slate-900/40">
        <AnimatedBackground
          showGrid={false}
          showGlow
          showParticles
          showElectricLines={false}
        />

        <SectionGlow
          size={400}
          color="cyan"
          className="-left-48 top-10 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="mx-auto max-w-3xl text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-blue-200 bg-blue-50 text-blue-600 dark:border-blue-900/60 dark:bg-blue-950/30 dark:text-cyan-400">
                <BookOpen size={25} />
              </div>

              <h2 className="mt-6 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
                Learn by building
              </h2>

              <p className="mt-5 text-lg leading-8 text-slate-600 dark:text-slate-400">
                Our approach focuses on understanding concepts and then
                applying them to practical development work.
              </p>
            </div>
          </Reveal>

          <div className="mt-16 grid gap-6 md:grid-cols-3">
            {[
              {
                number: "01",
                title: "Learn",
                description:
                  "Understand the fundamentals and concepts required to work with modern technologies.",
              },
              {
                number: "02",
                title: "Build",
                description:
                  "Apply what you learn by developing practical projects and real applications.",
              },
              {
                number: "03",
                title: "Get Certified",
                description:
                  "Complete the required course work and receive your certificate after successful completion.",
              },
            ].map((step, index) => (
              <Reveal
                key={step.number}
                delay={index * 120}
              >
                <FloatingCard
                  floating={false}
                  rotate={false}
                  glow={false}
                  className="h-full p-8"
                >
                  <span className="text-5xl font-black text-blue-100 dark:text-blue-950">
                    {step.number}
                  </span>

                  <h3 className="mt-5 text-xl font-bold text-slate-900 dark:text-white">
                    {step.title}
                  </h3>

                  <p className="mt-4 text-sm leading-7 text-slate-600 dark:text-slate-400">
                    {step.description}
                  </p>
                </FloatingCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* =========================================================
          BENEFITS
      ========================================================= */}

      <section className="relative overflow-hidden py-28">
        <SectionGlow
          size={350}
          color="blue"
          className="right-[-140px] top-10 opacity-10"
        />

        <div className="relative z-10 mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="grid items-center gap-14 lg:grid-cols-2">
              <div>
                <span className="text-sm font-semibold uppercase tracking-wider text-blue-600 dark:text-cyan-400">
                  Why Learn With SPE
                </span>

                <h2 className="mt-4 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
                  Focus on skills you can actually use.
                </h2>

                <p className="mt-6 leading-8 text-slate-600 dark:text-slate-400">
                  Our courses are structured around practical development,
                  helping learners move from understanding concepts to
                  actually creating working digital products.
                </p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                {[
                  "Project-focused learning",
                  "Modern technologies",
                  "Practical development skills",
                  "Course completion certificate",
                ].map((benefit, index) => (
                  <div
                    key={benefit}
                    className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
                  >
                    <CheckCircle2
                      size={20}
                      className="mt-0.5 shrink-0 text-blue-600 dark:text-cyan-400"
                    />

                    <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                      {benefit}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* =========================================================
          CTA
      ========================================================= */}

      <section className="relative overflow-hidden border-t border-slate-200 py-24 dark:border-slate-800">
        <SectionGlow
          size={450}
          color="cyan"
          className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-15"
        />

        <div className="relative z-10 mx-auto max-w-4xl px-6 text-center">
          <Reveal>
            <div className="rounded-3xl border border-slate-200 bg-slate-50 p-10 dark:border-slate-800 dark:bg-slate-900/70 md:p-14">
              <Award
                size={42}
                className="mx-auto text-blue-600 dark:text-cyan-400"
              />

              <h2 className="mt-6 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl dark:text-white">
                Ready to start learning?
              </h2>

              <p className="mx-auto mt-5 max-w-2xl leading-8 text-slate-600 dark:text-slate-400">
                Choose a course, build practical skills and take the next
                step toward your technology career.
              </p>

              <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
                <AnimatedButton>
                  <Link
                    to="#courses"
                    className="inline-flex items-center gap-2"
                  >
                    Explore Courses
                    <ArrowRight size={17} />
                  </Link>
                </AnimatedButton>

                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300 px-6 py-3 text-sm font-semibold text-slate-800 transition hover:border-blue-500 hover:text-blue-600 dark:border-slate-700 dark:text-slate-200 dark:hover:border-cyan-500 dark:hover:text-cyan-400"
                >
                  Contact Us
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </main>
  );
};

export default Courses;