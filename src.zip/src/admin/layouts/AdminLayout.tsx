import { useEffect, useState } from "react";
import { Navigate, Outlet } from "react-router-dom";

import { supabase } from "../../lib/supabase";

import AdminHeader from "../components/AdminHeader";
import AdminSidebar from "../components/AdminSidebar";

type AuthStatus =
  | "checking"
  | "authorized"
  | "unauthorized";

const AdminLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [status, setStatus] =
    useState<AuthStatus>("checking");

  useEffect(() => {
    let mounted = true;

    const checkAdminAccess = async () => {
      try {
        /*
         * Get the currently authenticated Supabase session.
         */
        const {
          data: { session },
        } = await supabase.auth.getSession();

        /*
         * No authenticated user.
         */
        if (!session?.user) {
          if (mounted) {
            setStatus("unauthorized");
          }

          return;
        }

        /*
         * Check the user's role.
         */
        const { data: profile, error } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", session.user.id)
          .single();

        /*
         * Authentication succeeded but authorization failed.
         */
        if (error || profile?.role !== "admin") {
          await supabase.auth.signOut();

          if (mounted) {
            setStatus("unauthorized");
          }

          return;
        }

        /*
         * User is authenticated and authorized.
         */
        if (mounted) {
          setStatus("authorized");
        }
      } catch (error) {
        console.error(
          "Admin authorization error:",
          error
        );

        if (mounted) {
          setStatus("unauthorized");
        }
      }
    };

    checkAdminAccess();

    /*
     * Keep the admin panel synchronized with Supabase Auth.
     *
     * Example:
     * User signs out in another tab → admin panel
     * automatically redirects to login.
     */
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(
      (event) => {
        if (
          event === "SIGNED_OUT" ||
          event === "SIGNED_IN" ||
          event === "TOKEN_REFRESHED"
        ) {
          checkAdminAccess();
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  /*
   * Loading state
   */
  if (status === "checking") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-100 dark:bg-slate-950">
        <div className="flex flex-col items-center gap-4">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-slate-300 border-t-cyan-500 dark:border-slate-700 dark:border-t-cyan-400" />

          <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
            Verifying admin access...
          </p>
        </div>
      </div>
    );
  }

  /*
   * Unauthorized users are redirected to login.
   */
  if (status === "unauthorized") {
    return (
      <Navigate
        to="/admin/login"
        replace
      />
    );
  }

  /*
   * Authorized admin application.
   */
  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950">
      <AdminSidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <div className="lg:pl-64">
        <AdminHeader
          onMenuClick={() =>
            setSidebarOpen(true)
          }
        />

        <main className="min-h-[calc(100vh-64px)] p-4 md:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;