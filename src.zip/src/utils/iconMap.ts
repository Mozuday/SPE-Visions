// src/utils/iconMap.tsx
//
// Admin panel stores an icon "key" (plain text) alongside each
// course/service/internship row instead of a component. This maps
// that key to an actual lucide-react icon for rendering.
//
// If you add a new icon option in the admin forms, add the matching
// entry here too.

import {
  BookOpen,
  Code2,
  Database,
  Smartphone,
  Monitor,
  Globe,
  Laptop,
  Bug,
  Wrench,
  Sparkles,
  ShieldCheck,
  Zap,
  BriefcaseBusiness,
  type LucideIcon,
} from "lucide-react";

export const iconMap: Record<string, LucideIcon> = {
  "book-open": BookOpen,
  code: Code2,
  database: Database,
  smartphone: Smartphone,
  monitor: Monitor,
  globe: Globe,
  laptop: Laptop,
  bug: Bug,
  wrench: Wrench,
  sparkles: Sparkles,
  shield: ShieldCheck,
  zap: Zap,
  briefcase: BriefcaseBusiness,
};

export const resolveIcon = (key?: string | null): LucideIcon =>
  (key && iconMap[key]) || Sparkles;